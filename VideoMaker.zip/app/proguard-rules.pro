# Media3 / reflection used by the app (speed effect, force-audio-track)
-keep class androidx.media3.effect.** { *; }
-keep class androidx.media3.transformer.** { *; }
-keep class androidx.media3.common.audio.** { *; }
-dontwarn androidx.media3.**
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn org.checkerframework.**
-keepattributes *Annotation*,Signature,InnerClasses
