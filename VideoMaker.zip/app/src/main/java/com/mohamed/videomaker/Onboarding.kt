package com.mohamed.videomaker

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class OnPage(val icon: ImageVector, val title: String, val body: String)

/** شاشات الترحيب (تظهر أول مرة فقط). */
@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val pages = listOf(
        OnPage(Icons.Filled.VideoLibrary, "اجمع صورك وفيديوهاتك", "أضف صورًا وفيديوهات بأي مدة، وقصّ ورتّب مقاطعك بسهولة على التايم لاين."),
        OnPage(Icons.Filled.MusicNote, "أضف الصوت والنصوص", "موسيقى وتلاوات وتسجيل صوتي، مع نصوص وملصقات وملفات ترجمة SRT."),
        OnPage(Icons.Filled.FileDownload, "صدّر بجودة عالية", "حتى 1080p بدون علامة مائية وبدون اشتراكات، والمشاريع بتتحفظ تلقائيًا.")
    )
    var page by rememberSaveable { mutableStateOf(0) }
    val last = page == pages.lastIndex
    BackHandler(enabled = page > 0) { page-- }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(VMColors.Accent.copy(alpha = 0.18f), VMColors.Bg)))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth()) {
                Spacer(Modifier.weight(1f))
                if (!last) {
                    Box(Modifier.clip(RoundedCornerShape(12.dp)).clickable { onDone() }.padding(10.dp)) {
                        Text("تخطي", color = VMColors.TextDim, fontSize = 14.sp)
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            LogoMark(88.dp)
            Spacer(Modifier.height(36.dp))
            val p = pages[page]
            Box(
                modifier = Modifier.size(72.dp).clip(CircleShape).background(VMColors.Surface2),
                contentAlignment = Alignment.Center
            ) {
                Icon(p.icon, contentDescription = null, tint = VMColors.Accent, modifier = Modifier.size(38.dp))
            }
            Spacer(Modifier.height(24.dp))
            Text(p.title, color = VMColors.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text(p.body, color = VMColors.TextDim, fontSize = 15.sp, textAlign = TextAlign.Center, lineHeight = 23.sp)
            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (i in pages.indices) {
                    Box(
                        Modifier
                            .size(if (i == page) 22.dp else 8.dp, 8.dp)
                            .clip(CircleShape)
                            .background(if (i == page) VMColors.Accent else VMColors.Surface3)
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(VMColors.Accent)
                    .clickable { if (last) onDone() else page++ }
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(if (last) "ابدأ الآن" else "التالي", color = Color.Black, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
