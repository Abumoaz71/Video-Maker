package com.mohamed.videomaker

import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.material3.Text as M3Text

/**
 * الترجمة: كل النصوص مكتوبة بالعربية في الكود، وعند اختيار الإنجليزية تُترجم وقت العرض.
 * هذه الدالة تحل محل Text الخاصة بـ Material3 داخل نفس الحزمة.
 */
@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    maxLines: Int = Int.MAX_VALUE
) {
    M3Text(
        text = tr(text),
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        maxLines = maxLines,
        style = LocalTextStyle.current
    )
}

private val DIGIT_SEC = Regex("(\\d) ث")
private val DIGIT_MIN = Regex("(\\d) د")

fun tr(s: String): String {
    if (AppSettings.isArabic || s.isEmpty()) return s
    EXACT[s]?.let { return it }
    var out = s
    for ((k, v) in PHRASES) {
        if (out.contains(k)) out = out.replace(k, v)
    }
    out = DIGIT_SEC.replace(out, "$1 s")
    out = DIGIT_MIN.replace(out, "$1 min")
    return out
}

/** عبارات داخل نصوص ديناميكية (فيها أرقام أو أسماء). */
private val PHRASES: List<Pair<String, String>> = listOf(
    "تم مد مدة الصورة لتطابق طول الصوت" to "Image extended to match audio length",
    "فشل بدء التصدير: " to "Could not start export: ",
    "مدة عرض الصورة: " to "Image duration: ",
    "طول الصوت: " to "Audio length: ",
    " · المدة " to " · Duration ",
    " · الحجم التقريبي " to " · Approx. size ",
    " — يدوم " to " — lasts ",
    "يبدأ " to "Starts ",
    "ملصق " to "Sticker ",
    "المقطع الأصلي " to "Original ",
    " · المحدد " to " · Selected ",
    "تم استيراد " to "Imported ",
    " سطر ترجمة" to " subtitle lines",
    " مقطع" to " clips"
)

private val EXACT: Map<String, String> = mapOf(
    // عام
    "تم" to "Done",
    "حسنًا" to "OK",
    "إلغاء" to "Cancel",
    "تطبيق" to "Apply",
    "العربية" to "العربية",
    "English" to "English",
    // الرئيسية
    "صانع الفيديو" to "Video Maker",
    "مونتاج كامل مجاني بدون علامة مائية ولا اشتراك" to "Full video editing — free, no watermark, no subscription",
    "＋ مشروع جديد" to "＋ New project",
    "مشروع جديد" to "New project",
    "ابدأ بمشروع فاضي" to "Start an empty project",
    "فيديو وصور" to "Video & photos",
    "صوت وموسيقى" to "Audio & music",
    "نصوص وملصقات" to "Text & stickers",
    "فلاتر وحركة" to "Filters & motion",
    "تحكم بالسرعة" to "Speed control",
    "تصدير حتى 1080p" to "Export up to 1080p",
    "صور وفيديوهات بأي مدة · صوت وموسيقى وتسجيل · نصوص وملصقات · فلاتر وسرعة وحركة · تصدير حتى 1080p" to
        "Photos and videos of any length · audio, music and recording · text and stickers · filters, speed and motion · export up to 1080p",
    // الإعدادات
    "الإعدادات" to "Settings",
    "اللغة" to "Language",
    "المظهر" to "Appearance",
    "النمط" to "Style",
    "لون التطبيق" to "Accent colour",
    "التصدير الافتراضي" to "Default export",
    "عن التطبيق" to "About",
    "الإصدار 2.0" to "Version 2.0",
    "داكن" to "Dark",
    "أسود" to "Black",
    "فاتح" to "Light",
    "فيروزي" to "Teal",
    "بنفسجي" to "Violet",
    "أزرق" to "Blue",
    "برتقالي" to "Orange",
    "وردي" to "Pink",
    "أخضر" to "Green",
    "التغييرات بتتحفظ تلقائيًا." to "Changes are saved automatically.",
    "تطبيق مونتاج مجاني بالكامل: بدون علامة مائية، وبدون اشتراكات، وبدون إعلانات." to
        "A fully free video editor: no watermark, no subscriptions, no ads.",
    // المحرر
    "تصدير" to "Export",
    "تشغيل" to "Play",
    "تكبير" to "Zoom",
    "تقسيم" to "Split",
    "المدة" to "Duration",
    "السرعة" to "Speed",
    "الصوت" to "Volume",
    "فصل الصوت" to "Detach audio",
    "تشغيل الصوت" to "Unmute",
    "كتم" to "Mute",
    "فلتر" to "Filter",
    "ألوان" to "Colours",
    "حركة" to "Motion",
    "تدوير" to "Rotate",
    "قلب أفقي" to "Flip",
    "ملء الإطار" to "Fill frame",
    "للخلف" to "Move left",
    "للأمام" to "Move right",
    "نسخ" to "Duplicate",
    "حذف" to "Delete",
    "المستوى" to "Level",
    "تلاشي" to "Fade",
    "تعديل" to "Edit",
    "وسائط" to "Media",
    "صوت" to "Audio",
    "تسجيل" to "Record",
    "نص" to "Text",
    "ملصقات" to "Stickers",
    "الأبعاد" to "Aspect",
    "أضف فيديو أو صورة للبدء" to "Add a video or photo to start",
    "إضافة" to "Add",
    "اضغط + لإضافة فيديو أو صور" to "Tap + to add videos or photos",
    // جديد
    "الصوت لم يظهر في التصدير الأول، جاري المعالجة بطريقة بديلة..." to "Audio was missing in the first export; retrying with an alternative method...",
    "فشل دمج الصوت: " to "Audio merge failed: ",
    "اكتب الوقت بالضبط" to "Enter the exact time",
    "قص" to "Trim",
    "قص المقطع" to "Trim clip",
    "قص الصوت" to "Trim audio",
    "البداية" to "Start",
    "النهاية" to "End",
    "من المؤشر" to "At playhead",
    "تشغيل المقطع" to "Play clip",
    "إعادة الأصل" to "Reset",
    "مشاريعك" to "Your projects",
    "حذف المشروع؟" to "Delete project?",
    "سيتم حذف المشروع نهائيًا من الجهاز." to "The project will be permanently deleted from this device.",
    "تعذر فتح المشروع" to "Could not open the project",
    "بعض الملفات لم تعد متاحة وتم حذفها من المشروع" to "Some files are no longer available and were removed from the project",
    "مشروعك بيتحفظ تلقائيًا، وتقدر تكمله بعدين من الشاشة الرئيسية." to "Your project is saved automatically. You can continue it later from the home screen.",
    "ترجمة" to "Subtitles",
    "ملف الترجمة فاضي أو غير مدعوم" to "The subtitle file is empty or unsupported",
    "الاستخدام" to "Usage",
    "مدة الصورة الافتراضية" to "Default image duration",
    "سياسة الخصوصية" to "Privacy policy",
    "مشاركة التطبيق" to "Share the app",
    "قيّم التطبيق" to "Rate the app",
    "تخطي" to "Skip",
    "التالي" to "Next",
    "ابدأ الآن" to "Get started",
    "اجمع صورك وفيديوهاتك" to "Bring your photos and videos",
    "أضف صورًا وفيديوهات بأي مدة، وقصّ ورتّب مقاطعك بسهولة على التايم لاين." to "Add photos and videos of any length, then trim and arrange clips on the timeline.",
    "أضف الصوت والنصوص" to "Add audio and text",
    "موسيقى وتلاوات وتسجيل صوتي، مع نصوص وملصقات وملفات ترجمة SRT." to "Music, recitations and voice recording, plus text, stickers and SRT subtitle files.",
    "صدّر بجودة عالية" to "Export in high quality",
    "حتى 1080p بدون علامة مائية وبدون اشتراكات، والمشاريع بتتحفظ تلقائيًا." to "Up to 1080p with no watermark and no subscription. Projects are saved automatically.",
    "الإصدار 2.2" to "Version 2.2",
    // رسائل
    "مقدرتش أقرأ واحد من الملفات" to "Could not read one of the files",
    "ملف صوتي" to "Audio file",
    "الملف الصوتي مش مقروء" to "The audio file can't be read",
    "حرّك المؤشر داخل المقطع الصوتي" to "Move the playhead inside the audio clip",
    "حرّك المؤشر داخل المقطع المراد تقسيمه" to "Move the playhead inside the clip to split",
    "أضف صوتًا أولًا" to "Add audio first",
    "المدة مطابقة للصوت بالفعل" to "Duration already matches the audio",
    "الصورة مفيهاش صوت" to "Images have no audio",
    "صوت من فيديو" to "Audio from video",
    "تم فصل الصوت في مسار مستقل" to "Audio detached to its own track",
    "تعذر بدء التسجيل" to "Could not start recording",
    "تسجيل صوتي" to "Voice recording",
    "التسجيل قصير جدًا" to "Recording too short",
    "اتعمل الفيديو بس معرفتش أحفظه في المعرض" to "The video was created but could not be saved to the gallery",
    "حصل خطأ أثناء التصدير" to "An error occurred during export",
    "لازم تسمح بالميكروفون عشان التسجيل" to "Allow microphone access to record",
    "ضيف صورة أو فيديو الأول" to "Add a photo or video first",
    // حوارات
    "تعذر التصدير" to "Export failed",
    "خروج" to "Exit",
    "إكمال التعديل" to "Keep editing",
    "إغلاق المشروع؟" to "Close project?",
    "المشروع غير محفوظ، وهيتمسح لو خرجت. صدّر الفيديو الأول لو خلصت." to
        "The project isn't saved and will be lost if you leave. Export the video first if you're done.",
    "ابدأ التصدير" to "Start export",
    "إعدادات التصدير" to "Export settings",
    "الدقة" to "Resolution",
    "معدل الإطارات" to "Frame rate",
    "الجودة" to "Quality",
    "هيتحفظ في المعرض داخل مجلد VideoMaker. سيب الشاشة مفتوحة أثناء التصدير." to
        "Saved to your gallery in the VideoMaker folder. Keep the screen on while exporting.",
    "جاري تصدير الفيديو" to "Exporting video",
    "متقفلش التطبيق ولا الشاشة لحد ما يخلص. الفيديو الطويل بياخد وقت." to
        "Don't close the app or turn off the screen until it finishes. Long videos take time.",
    "✓ تم حفظ الفيديو في المعرض" to "✓ Video saved to gallery",
    "مشاركة الفيديو" to "Share video",
    "مشاركة" to "Share",
    "رجوع للتعديل" to "Back to editing",
    // فلاتر وحركات وخطوط وجودة
    "بدون" to "None",
    "حيوي" to "Vivid",
    "دافئ" to "Warm",
    "بارد" to "Cool",
    "مضيء" to "Bright",
    "درامي" to "Dramatic",
    "باهت" to "Faded",
    "سيبيا" to "Sepia",
    "أبيض وأسود" to "B&W",
    "أسود درامي" to "Noir",
    "تقريب بطيء" to "Slow zoom in",
    "إبعاد بطيء" to "Slow zoom out",
    "عادي" to "Normal",
    "كلاسيكي" to "Serif",
    "ضيق" to "Condensed",
    "ثابت" to "Mono",
    "يدوي" to "Script",
    "حر" to "Casual",
    "اقتصادية" to "Economy",
    "متوسطة" to "Medium",
    "عالية" to "High",
    // اللوحات
    "دقائق" to "Minutes",
    "ثواني" to "Seconds",
    "مطابقة طول الصوت" to "Match audio length",
    "سرعة المقطع" to "Clip speed",
    "تغيير السرعة غير مدعوم في إصدار المكتبة الحالي للتصدير (يظهر في المعاينة فقط)." to
        "Speed change isn't supported by the current export library version (preview only).",
    "صوت المقطع" to "Clip volume",
    "مستوى الصوت" to "Volume level",
    "المعاينة تتوقف عند 100%، والزيادة تظهر في الملف النهائي." to
        "Preview caps at 100%; any boost appears in the final file.",
    "تلاشي الصوت" to "Audio fade",
    "تلاشي عند البداية" to "Fade in",
    "تلاشي عند النهاية" to "Fade out",
    "الفلاتر" to "Filters",
    "تطبيق على كل المقاطع" to "Apply to all clips",
    "تعديل الألوان" to "Colour adjust",
    "السطوع" to "Brightness",
    "التباين" to "Contrast",
    "التشبع" to "Saturation",
    "الدفء" to "Warmth",
    "إعادة ضبط" to "Reset",
    "الحركة والانتقال" to "Motion & transitions",
    "التلاشي والتكبير يتطبقوا في أول وآخر المقطع، والتقريب/الإبعاد البطيء على طول المقطع." to
        "Fade and zoom apply at the start and end of the clip; slow zoom runs across the whole clip.",
    "تعديل النص" to "Edit text",
    "النص" to "Text",
    "عريض" to "Bold",
    "مائل" to "Italic",
    "نمط النص" to "Text style",
    "لون النص" to "Text colour",
    "الخلفية" to "Background",
    "الحجم" to "Size",
    "الدوران" to "Rotation",
    "ابدأ من المؤشر" to "Start at playhead",
    "انتهِ عند المؤشر" to "End at playhead",
    "اسحب النص في المعاينة لتحريكه، واستخدم إصبعين للتكبير والتدوير." to
        "Drag the text in the preview to move it; use two fingers to scale and rotate.",
    "ملصقات" to "Stickers",
    "أبعاد الفيديو" to "Video aspect ratio",
    "16:9 لليوتيوب · 9:16 للريلز وتيك توك · 1:1 و4:5 لإنستجرام." to
        "16:9 for YouTube · 9:16 for Reels & TikTok · 1:1 and 4:5 for Instagram.",
    "● جاري التسجيل... تكلّم الآن" to "● Recording… speak now",
    "■ إيقاف وحفظ" to "■ Stop & save",
    "يبدأ التسجيل من موضع المؤشر ويشغّل المعاينة أثناءه. استخدم سماعات لتجنب الصدى." to
        "Recording starts at the playhead and plays the preview. Use headphones to avoid echo.",
    "● ابدأ التسجيل" to "● Start recording"
)
