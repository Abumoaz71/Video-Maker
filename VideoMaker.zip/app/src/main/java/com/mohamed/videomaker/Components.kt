package com.mohamed.videomaker

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Tool(
    val icon: ImageVector?,
    val label: String,
    val glyph: String? = null,
    val enabled: Boolean = true,
    val active: Boolean = false,
    val danger: Boolean = false,
    val onClick: () -> Unit
)

@Composable
fun ToolBar(tools: List<Tool>, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(VMColors.Surface)
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 6.dp, horizontal = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        for (t in tools) ToolButton(t)
    }
}

@Composable
fun ToolButton(t: Tool) {
    val tint = when {
        !t.enabled -> Color(0xFF5A6076)
        t.danger -> VMColors.Danger
        t.active -> VMColors.Accent
        else -> VMColors.Text
    }
    Column(
        modifier = Modifier
            .width(66.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(enabled = t.enabled) { t.onClick() }
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(26.dp), contentAlignment = Alignment.Center) {
            if (t.icon != null) {
                Icon(t.icon, contentDescription = t.label, tint = tint, modifier = Modifier.size(24.dp))
            } else {
                Text(t.glyph ?: "", color = tint, fontSize = 18.sp)
            }
        }
        Text(t.label, color = tint, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) VMColors.Accent else VMColors.Surface3)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Text(
            label,
            color = if (selected) Color.Black else VMColors.Text,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
fun <T> ChipRow(items: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for (item in items) {
            Chip(label(item), item == selected) { onSelect(item) }
        }
    }
}

@Composable
fun SmallButton(text: String, accent: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(
                when {
                    !enabled -> VMColors.Surface2
                    accent -> VMColors.Accent
                    else -> VMColors.Surface3
                }
            )
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = 14.dp, vertical = 9.dp)
    ) {
        Text(
            text,
            color = when {
                !enabled -> VMColors.TextDim
                accent -> Color.Black
                else -> VMColors.Text
            },
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

/** إطار اللوحات السفلية: عنوان + زر تأكيد. */
@Composable
fun PanelFrame(title: String, onClose: () -> Unit, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(VMColors.Surface)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = VMColors.Text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(VMColors.Accent)
                    .clickable { onClose() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Check, contentDescription = "تم", tint = Color.Black, modifier = Modifier.size(20.dp))
            }
        }
        content()
    }
}

/** سلايدر مع نقطة تراجع واحدة لكل سحبة. */
@Composable
fun EditSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    onStart: () -> Unit,
    onChange: (Float) -> Unit
) {
    var dragging by remember { mutableStateOf(false) }
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = VMColors.TextDim, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            Text(valueText, color = VMColors.Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = {
                if (!dragging) {
                    dragging = true
                    onStart()
                }
                onChange(it)
            },
            onValueChangeFinished = { dragging = false },
            valueRange = range
        )
    }
}

@Composable
fun ColorSwatches(colors: List<Int>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for (c in colors) {
            val isSel = c == selected
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(if ((c ushr 24) == 0) Color(0xFF444444) else Color(c))
                    .border(if (isSel) 3.dp else 1.dp, if (isSel) VMColors.Accent else Color(0xFF6A708A), CircleShape)
                    .clickable { onSelect(c) },
                contentAlignment = Alignment.Center
            ) {
                if ((c ushr 24) == 0) Text("∅", color = Color.White, fontSize = 14.sp)
            }
        }
    }
}
