package com.mohamed.videomaker

data class SubtitleCue(val startMs: Long, val endMs: Long, val text: String)

private val TIME = Regex("(?:(\\d{1,2}):)?(\\d{1,2}):(\\d{2})[,.](\\d{1,3})")
private val TAGS = Regex("<[^>]+>|\\{\\\\[^}]*\\}")

private fun parseTime(s: String): Long? {
    val m = TIME.find(s.trim()) ?: return null
    val h = m.groupValues[1].toLongOrNull() ?: 0L
    val mi = m.groupValues[2].toLong()
    val se = m.groupValues[3].toLong()
    var ms = m.groupValues[4]
    while (ms.length < 3) ms += "0"
    return ((h * 60 + mi) * 60 + se) * 1000 + ms.toLong()
}

/** يقرأ ملفات SRT و WebVTT. */
fun parseSubtitles(raw: String): List<SubtitleCue> {
    val text = raw.removePrefix("﻿").replace("\r\n", "\n").replace('\r', '\n')
    val out = ArrayList<SubtitleCue>()
    for (block in text.split(Regex("\n\\s*\n"))) {
        val lines = block.split('\n')
        val idx = lines.indexOfFirst { it.contains("-->") }
        if (idx < 0) continue
        val parts = lines[idx].split("-->")
        if (parts.size < 2) continue
        val start = parseTime(parts[0]) ?: continue
        val end = parseTime(parts[1].trim().split(' ')[0]) ?: continue
        val body = lines.drop(idx + 1).joinToString("\n") { it.trim() }
            .replace(TAGS, "")
            .trim()
        if (body.isEmpty()) continue
        out += SubtitleCue(start, end, body)
    }
    return out
}
