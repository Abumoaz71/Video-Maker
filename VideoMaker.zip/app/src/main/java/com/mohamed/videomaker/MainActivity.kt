package com.mohamed.videomaker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.runtime.SideEffect
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import kotlinx.coroutines.delay
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val vm: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        var keepSplash = true
        splash.setKeepOnScreenCondition { keepSplash }
        Handler(Looper.getMainLooper()).postDelayed({ keepSplash = false }, 700)

        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        AppSettings.init(this)
        if (savedInstanceState == null) vm.exportConfig = AppSettings.exportConfig

        setContent {
            AppTheme {
                val lightBars = AppSettings.mode == ThemeMode.LIGHT
                SideEffect {
                    val c = WindowInsetsControllerCompat(window, window.decorView)
                    c.isAppearanceLightStatusBars = lightBars
                    c.isAppearanceLightNavigationBars = lightBars
                }
                val dir = if (AppSettings.isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
                CompositionLocalProvider(LocalLayoutDirection provides dir) {
                    Root(vm)
                }
            }
        }
    }

    override fun onStop() {
        vm.engine.pause()
        vm.flushSave()
        super.onStop()
    }
}

@Composable
private fun Root(vm: EditorViewModel) {
    var started by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    val hasContent = vm.project.clips.isNotEmpty() || vm.project.audios.isNotEmpty() || vm.project.texts.isNotEmpty()
    Box(Modifier.fillMaxSize().background(VMColors.Bg)) {
        if (!AppSettings.onboarded) {
            OnboardingScreen(onDone = {
                AppSettings.onboarded = true
                AppSettings.save()
            })
        } else if (!started && !hasContent) {
            HomeScreen(vm, onStart = { started = true }, onSettings = { showSettings = true })
        } else {
            EditorScreen(vm, onExit = { started = false }, onSettings = { showSettings = true })
        }
        if (showSettings && AppSettings.onboarded) {
            SettingsScreen(onBack = { showSettings = false })
        }
    }
}

// ------------------------------------------------------------------ المحرر

@Composable
private fun EditorScreen(vm: EditorViewModel, onExit: () -> Unit, onSettings: () -> Unit) {
    val context = LocalContext.current
    var dpPerSec by rememberSaveable { mutableStateOf(24f) }
    var showExport by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isNotEmpty()) vm.addMedia(uris)
    }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        for (u in uris) vm.addAudio(u)
    }
    val pickSubtitles = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importSubtitles(uri)
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startRecording() else vm.message = "لازم تسمح بالميكروفون عشان التسجيل"
    }

    val requestRecord = {
        val ok = context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (ok) vm.startRecording() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    val addMedia = {
        pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
    }
    val addAudio = { pickAudio.launch(arrayOf("audio/*", "video/mp4")) }

    BackHandler {
        when {
            vm.exporting -> {}
            vm.resultUri != null -> vm.dismissResult()
            vm.panel != null -> {
                if (vm.recording) vm.stopRecording()
                vm.panel = null
            }
            vm.selection != null -> vm.selection = null
            else -> confirmExit = true
        }
    }

    // الشاشة تفضل صاحية أثناء التصدير
    val window = (context as? ComponentActivity)?.window
    DisposableEffect(vm.exporting) {
        if (vm.exporting) window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    LaunchedEffect(vm.message) {
        if (vm.message != null) {
            delay(3200)
            vm.clearMessage()
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            TopBar(
                vm,
                onClose = { confirmExit = true },
                onSettings = onSettings,
                onExport = {
                    if (vm.project.clips.isEmpty()) vm.message = "ضيف صورة أو فيديو الأول" else showExport = true
                }
            )
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth().background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                PreviewArea(vm)
            }
            TransportRow(
                vm,
                onZoomOut = { dpPerSec = (dpPerSec / 1.4f).coerceAtLeast(1f) },
                onZoomIn = { dpPerSec = (dpPerSec * 1.4f).coerceAtMost(240f) }
            )
            TimelineView(vm, dpPerSec, onAddMedia = { addMedia() }, modifier = Modifier.fillMaxWidth().height(178.dp))
            val p = vm.panel
            if (p != null) {
                PanelHost(vm, p, onClose = {
                    if (vm.recording) vm.stopRecording()
                    vm.panel = null
                }, onRequestRecord = { requestRecord() })
            } else {
                ToolBar(toolsFor(vm, addMedia, addAudio, { pickSubtitles.launch(arrayOf("*/*")) }))
            }
        }

        // رسالة علوية
        val msg = vm.message
        if (msg != null) {
            Box(
                modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(top = 56.dp, start = 24.dp, end = 24.dp),
                contentAlignment = Alignment.TopCenter
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xEE2E3242))
                        .clickable { vm.clearMessage() }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(msg, color = Color(0xFFF2F4F8), fontSize = 13.sp)
                }
            }
        }

        if (vm.busy) {
            Box(
                Modifier.fillMaxSize().background(Color(0x66000000)).clickable(enabled = true) {},
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = VMColors.Accent)
            }
        }

        if (showExport) {
            ExportDialog(vm, onDismiss = { showExport = false }, onStart = {
                showExport = false
                vm.startExport()
            })
        }

        if (vm.exporting) ExportProgressOverlay(vm)

        val res = vm.resultUri
        if (res != null) ResultScreen(vm, res)

        val err = vm.exportError
        if (err != null && !vm.exporting) {
            AlertDialog(
                onDismissRequest = { vm.dismissResult() },
                confirmButton = { TextButton(onClick = { vm.dismissResult() }) { Text("حسنًا") } },
                title = { Text("تعذر التصدير") },
                text = { Text(err, fontSize = 13.sp) }
            )
        }

        if (confirmExit) {
            AlertDialog(
                onDismissRequest = { confirmExit = false },
                confirmButton = {
                    TextButton(onClick = {
                        confirmExit = false
                        vm.engine.pause()
                        vm.selection = null
                        vm.panel = null
                        vm.resetProject()
                        onExit()
                    }) { Text("خروج", color = VMColors.Danger) }
                },
                dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("إكمال التعديل") } },
                title = { Text("إغلاق المشروع؟") },
                text = { Text("مشروعك بيتحفظ تلقائيًا، وتقدر تكمله بعدين من الشاشة الرئيسية.", fontSize = 13.sp) }
            )
        }
    }
}

@Composable
fun IconBtn(icon: ImageVector, desc: String, enabled: Boolean = true, size: Int = 40, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(size.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            icon,
            contentDescription = desc,
            tint = if (enabled) VMColors.Text else Color(0xFF5A6076),
            modifier = Modifier.size((size * 0.55f).dp)
        )
    }
}

@Composable
private fun TopBar(vm: EditorViewModel, onClose: () -> Unit, onSettings: () -> Unit, onExport: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(VMColors.Surface).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        IconBtn(Icons.Filled.Close, "إغلاق", onClick = onClose)
        IconBtn(Icons.Filled.Settings, "الإعدادات", onClick = onSettings)
        Spacer(Modifier.weight(1f))
        IconBtn(Icons.AutoMirrored.Filled.Undo, "تراجع", enabled = vm.canUndo) { vm.undo() }
        IconBtn(Icons.AutoMirrored.Filled.Redo, "إعادة", enabled = vm.canRedo) { vm.redo() }
        Spacer(Modifier.size(6.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(18.dp))
                .background(VMColors.Accent)
                .clickable { onExport() }
                .padding(horizontal = 18.dp, vertical = 8.dp)
        ) {
            Text("تصدير", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun TransportRow(vm: EditorViewModel, onZoomOut: () -> Unit, onZoomIn: () -> Unit) {
    val engine = vm.engine
    val total = vm.project.totalMs
    Row(
        modifier = Modifier.fillMaxWidth().background(VMColors.Surface).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
                formatTime(engine.positionMs) + " / " + formatTime(total),
                color = VMColors.TextDim,
                fontSize = 12.sp
            )
        }
        Spacer(Modifier.weight(1f))
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(VMColors.Accent)
                .clickable { if (!vm.recording) engine.toggle() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (engine.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = "تشغيل",
                tint = Color.Black,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(Modifier.weight(1f))
        IconBtn(Icons.Filled.ZoomOut, "تصغير", size = 36, onClick = onZoomOut)
        IconBtn(Icons.Filled.ZoomIn, "تكبير", size = 36, onClick = onZoomIn)
    }
}

// ------------------------------------------------------------------ أدوات الشريط السفلي

private fun toolsFor(vm: EditorViewModel, addMedia: () -> Unit, addAudio: () -> Unit, addSubtitles: () -> Unit): List<Tool> {
    val list = ArrayList<Tool>()
    val sel = vm.selection
    if (sel != null) {
        list += Tool(Icons.Filled.Close, "إلغاء") { vm.selection = null }
    }
    when (sel) {
        is Selection.Clip -> {
            val c = vm.clipById(sel.id)
            if (c != null) {
                list += Tool(Icons.Filled.ContentCut, "تقسيم") { vm.splitAtPlayhead() }
                if (c.isImage) {
                    list += Tool(Icons.Filled.Timer, "المدة") { vm.panel = Panel.TRIM_IMAGE }
                } else {
                    list += Tool(Icons.Filled.Crop, "قص") { vm.panel = Panel.TRIM }
                    list += Tool(Icons.Filled.Speed, "السرعة") { vm.panel = Panel.SPEED }
                    list += Tool(Icons.Filled.VolumeUp, "الصوت") { vm.panel = Panel.VOLUME }
                    list += Tool(Icons.Filled.MusicNote, "فصل الصوت") { vm.extractAudio() }
                    list += Tool(
                        if (c.muted) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                        if (c.muted) "تشغيل الصوت" else "كتم"
                    ) { vm.updateClip(c.id) { it.copy(muted = !it.muted) } }
                }
                list += Tool(Icons.Filled.Palette, "فلتر") { vm.panel = Panel.FILTER }
                list += Tool(Icons.Filled.Tune, "ألوان") { vm.panel = Panel.ADJUST }
                list += Tool(Icons.Filled.AutoAwesome, "حركة") { vm.panel = Panel.ANIM }
                list += Tool(Icons.Filled.RotateRight, "تدوير") {
                    vm.updateClip(c.id) { it.copy(rotation = (it.rotation + 90) % 360) }
                }
                list += Tool(Icons.Filled.Flip, "قلب أفقي", active = c.flipH) {
                    vm.updateClip(c.id) { it.copy(flipH = !it.flipH) }
                }
                list += Tool(Icons.Filled.Fullscreen, "ملء الإطار", active = c.fill) {
                    vm.updateClip(c.id) { it.copy(fill = !it.fill) }
                }
                list += Tool(Icons.Filled.ChevronLeft, "للخلف") { vm.moveSelectedClip(-1) }
                list += Tool(Icons.Filled.ChevronRight, "للأمام") { vm.moveSelectedClip(1) }
                list += Tool(Icons.Filled.ContentCopy, "نسخ") { vm.duplicateSelected() }
                list += Tool(Icons.Filled.Delete, "حذف", danger = true) { vm.deleteSelected() }
            }
        }
        is Selection.Audio -> {
            list += Tool(Icons.Filled.ContentCut, "تقسيم") { vm.splitAtPlayhead() }
            list += Tool(Icons.Filled.Crop, "قص") { vm.panel = Panel.TRIM }
            list += Tool(Icons.Filled.VolumeUp, "المستوى") { vm.panel = Panel.AUDIO_VOLUME }
            list += Tool(Icons.Filled.TrendingDown, "تلاشي") { vm.panel = Panel.AUDIO_FADE }
            list += Tool(Icons.Filled.ContentCopy, "نسخ") { vm.duplicateSelected() }
            list += Tool(Icons.Filled.Delete, "حذف", danger = true) { vm.deleteSelected() }
        }
        is Selection.Text -> {
            val t = vm.textById(sel.id)
            if (t != null && !t.isSticker) list += Tool(Icons.Filled.Edit, "تعديل") { vm.panel = Panel.TEXT_EDIT }
            list += Tool(Icons.Filled.Palette, "النمط") { vm.panel = Panel.TEXT_STYLE }
            list += Tool(Icons.Filled.ContentCopy, "نسخ") { vm.duplicateSelected() }
            list += Tool(Icons.Filled.Delete, "حذف", danger = true) { vm.deleteSelected() }
        }
        null -> {
            list += Tool(Icons.Filled.PhotoLibrary, "وسائط") { addMedia() }
            list += Tool(Icons.Filled.MusicNote, "صوت") { addAudio() }
            list += Tool(Icons.Filled.Mic, "تسجيل") { vm.panel = Panel.RECORD }
            list += Tool(Icons.Filled.TextFields, "نص") { vm.addText() }
            list += Tool(Icons.Filled.Subtitles, "ترجمة") { addSubtitles() }
            list += Tool(Icons.Filled.EmojiEmotions, "ملصقات") { vm.panel = Panel.STICKERS }
            list += Tool(Icons.Filled.AspectRatio, "الأبعاد") { vm.panel = Panel.ASPECT }
        }
    }
    return list
}

// ------------------------------------------------------------------ التصدير

private fun setExport(vm: EditorViewModel, cfg: ExportConfig) {
    vm.exportConfig = cfg
    AppSettings.exportConfig = cfg
    AppSettings.save()
}

@Composable
private fun ExportDialog(vm: EditorViewModel, onDismiss: () -> Unit, onStart: () -> Unit) {
    val cfg = vm.exportConfig
    val aspect = vm.project.aspect
    val (w, h) = cfg.size(aspect)
    val secs = vm.project.totalMs / 1000L
    val bytes = (cfg.bitrate(aspect).toLong() / 8L + 128_000L / 8L) * secs
    val mb = bytes / 1_048_576f
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onStart) { Text("ابدأ التصدير", color = VMColors.Accent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        title = { Text("إعدادات التصدير") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("الدقة", color = VMColors.TextDim, fontSize = 12.sp)
                ChipRow(ExportRes.entries.toList(), cfg.res, { it.label }) { setExport(vm, cfg.copy(res = it)) }
                Text("معدل الإطارات", color = VMColors.TextDim, fontSize = 12.sp)
                ChipRow(listOf(24, 30, 60), cfg.fps, { "$it fps" }) { setExport(vm, cfg.copy(fps = it)) }
                Text("الجودة", color = VMColors.TextDim, fontSize = 12.sp)
                ChipRow(ExportQuality.entries.toList(), cfg.quality, { it.label }) { setExport(vm, cfg.copy(quality = it)) }
                Text(
                    "${w}×${h} · المدة " + formatTime(vm.project.totalMs) + " · الحجم التقريبي " +
                        String.format(Locale.US, "%.0f MB", mb),
                    color = VMColors.Text,
                    fontSize = 12.sp
                )
                Text(
                    "هيتحفظ في المعرض داخل مجلد VideoMaker. سيب الشاشة مفتوحة أثناء التصدير.",
                    color = VMColors.TextDim,
                    fontSize = 11.sp
                )
            }
        }
    )
}

@Composable
private fun ExportProgressOverlay(vm: EditorViewModel) {
    Box(
        Modifier.fillMaxSize().background(VMColors.Bg.copy(alpha = 0.96f)).clickable(enabled = true) {},
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            LogoMark(72.dp)
            Text("جاري تصدير الفيديو", color = VMColors.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                String.format(Locale.US, "%d%%", (vm.exportProgress * 100).toInt()),
                color = VMColors.Accent,
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold
            )
            LinearProgressIndicator(
                progress = { vm.exportProgress.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = VMColors.Accent,
                trackColor = VMColors.Surface3
            )
            Text(
                "متقفلش التطبيق ولا الشاشة لحد ما يخلص. الفيديو الطويل بياخد وقت.",
                color = VMColors.TextDim,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
            SmallButton("إلغاء") { vm.cancelExport() }
        }
    }
}

@Composable
private fun ResultScreen(vm: EditorViewModel, uri: Uri) {
    val context = LocalContext.current
    Column(
        modifier = Modifier.fillMaxSize().background(VMColors.Bg).statusBarsPadding().navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "✓ تم حفظ الفيديو في المعرض",
            color = VMColors.Accent,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(16.dp)
        )
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth().background(Color.Black),
            factory = { ctx ->
                VideoView(ctx).apply {
                    val mc = MediaController(ctx)
                    mc.setAnchorView(this)
                    setMediaController(mc)
                    setVideoURI(uri)
                    setOnPreparedListener { it.isLooping = false; start() }
                }
            }
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(VMColors.Accent)
                    .clickable {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "video/mp4"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(send, tr("مشاركة الفيديو")))
                    }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) { Text("مشاركة", color = Color.Black, fontWeight = FontWeight.Bold) }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(VMColors.Surface3)
                    .clickable { vm.dismissResult() }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) { Text("رجوع للتعديل", color = VMColors.Text) }
        }
    }
}
