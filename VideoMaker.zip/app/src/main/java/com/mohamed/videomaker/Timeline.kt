package com.mohamed.videomaker

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.snapshotFlow

private val LANE_H = 28.dp
private val CLIP_H = 56.dp

/** يوزّع العناصر المتداخلة على مسارات (lanes). */
private fun assignLanes(spans: List<Triple<Long, Long, Long>>): Pair<Map<Long, Int>, Int> {
    val laneEnds = ArrayList<Long>()
    val result = HashMap<Long, Int>()
    for (s in spans.sortedBy { it.second }) {
        var lane = laneEnds.indexOfFirst { it <= s.second }
        if (lane < 0) {
            laneEnds.add(s.third)
            lane = laneEnds.size - 1
        } else {
            laneEnds[lane] = s.third
        }
        result[s.first] = lane
    }
    return Pair(result, maxOf(1, laneEnds.size))
}

@Composable
fun TimelineView(
    vm: EditorViewModel,
    dpPerSec: Float,
    onAddMedia: () -> Unit,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        val density = LocalDensity.current
        val project = vm.project
        val engine = vm.engine
        val maxMs = maxOf(
            project.totalMs,
            project.audioEndMs,
            project.texts.maxOfOrNull { it.endMs } ?: 0L,
            1000L
        )
        // حد أقصى لعرض المحتوى (قيد Compose على الأبعاد)
        val safeDpPerSec = minOf(dpPerSec, 150000f / density.density / (maxMs / 1000f))
        val ppm = with(density) { safeDpPerSec.dp.toPx() } / 1000f
        val contentDp: Dp = with(density) { (maxMs * ppm).toDp() }

        val scroll = rememberScrollState()
        val vScroll = rememberScrollState()
        val pos = engine.positionMs

        val programmatic = remember { booleanArrayOf(false) }

        // المؤشر → التمرير
        LaunchedEffect(pos, ppm) {
            if (!scroll.isScrollInProgress) {
                programmatic[0] = true
                scroll.scrollTo((pos * ppm).toInt())
                programmatic[0] = false
            }
        }
        // التمرير باللمس → المؤشر
        LaunchedEffect(scroll, ppm) {
            snapshotFlow { scroll.value }.collect { v ->
                if (scroll.isScrollInProgress && !programmatic[0]) engine.seekTo((v / ppm).toLong())
            }
        }
        // لمس التايم لاين أثناء التشغيل يوقف التشغيل
        LaunchedEffect(scroll) {
            scroll.interactionSource.interactions.collect { i ->
                if (i is DragInteraction.Start && engine.playing) engine.pause()
            }
        }

        BoxWithConstraints(modifier = modifier.fillMaxSize().background(VMColors.Bg)) {
            val half = maxWidth / 2

            Row(modifier = Modifier.fillMaxSize().horizontalScroll(scroll)) {
                Spacer(Modifier.width(half))
                Column(
                    modifier = Modifier
                        .width(contentDp + 80.dp)
                        .fillMaxHeight()
                        .verticalScroll(vScroll)
                ) {
                    Ruler(contentDp, ppm, maxMs)

                    // ---------- مسار النصوص ----------
                    if (project.texts.isNotEmpty()) {
                        val (lanes, count) = assignLanes(project.texts.map { Triple(it.id, it.startMs, it.endMs) })
                        Box(Modifier.fillMaxWidth().height(LANE_H * count + 4.dp).padding(top = 2.dp)) {
                            for (t in project.texts) {
                                val selected = (vm.selection as? Selection.Text)?.id == t.id
                                TrackBlock(
                                    x = with(density) { (t.startMs * ppm).toDp() },
                                    y = LANE_H * (lanes[t.id] ?: 0),
                                    width = with(density) { (t.durationMs * ppm).toDp() },
                                    height = LANE_H - 2.dp,
                                    color = VMColors.TextTrack,
                                    selected = selected,
                                    label = (if (t.isSticker) "ملصق " else "") + t.text.replace('\n', ' '),
                                    ppm = ppm,
                                    key = t.id,
                                    onTap = { vm.selection = Selection.Text(t.id); vm.panel = null },
                                    onMove = { vm.moveText(t.id, it) },
                                    onResizeStart = { vm.resizeTextEdge(t.id, true, it) },
                                    onResizeEnd = { vm.resizeTextEdge(t.id, false, it) },
                                    onDragStart = { vm.checkpoint() }
                                )
                            }
                        }
                    }

                    // ---------- المسار الرئيسي ----------
                    Row(
                        modifier = Modifier.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (c in project.clips) {
                            ClipBlock(vm, c, ppm)
                        }
                        Box(
                            modifier = Modifier
                                .padding(start = 6.dp)
                                .size(CLIP_H)
                                .clip(RoundedCornerShape(8.dp))
                                .background(VMColors.Accent)
                                .clickable { onAddMedia() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = "إضافة", tint = Color.Black)
                        }
                    }

                    // ---------- مسارات الصوت ----------
                    if (project.audios.isNotEmpty()) {
                        val (lanes, count) = assignLanes(project.audios.map { Triple(it.id, it.startMs, it.endMs) })
                        Box(Modifier.fillMaxWidth().height(LANE_H * count + 4.dp).padding(top = 2.dp)) {
                            for (a in project.audios) {
                                val selected = (vm.selection as? Selection.Audio)?.id == a.id
                                TrackBlock(
                                    x = with(density) { (a.startMs * ppm).toDp() },
                                    y = LANE_H * (lanes[a.id] ?: 0),
                                    width = with(density) { (a.lengthMs * ppm).toDp() },
                                    height = LANE_H - 2.dp,
                                    color = if (a.kind == AudioItem.KIND_VOICE) VMColors.VoiceTrack else VMColors.AudioTrack,
                                    selected = selected,
                                    label = a.name + "  " + formatTime(a.lengthMs),
                                    ppm = ppm,
                                    key = a.id,
                                    onTap = { vm.selection = Selection.Audio(a.id); vm.panel = null },
                                    onMove = { vm.moveAudio(a.id, it) },
                                    onResizeStart = { vm.resizeAudioEdge(a.id, true, it) },
                                    onResizeEnd = { vm.resizeAudioEdge(a.id, false, it) },
                                    onDragStart = { vm.checkpoint() }
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.width(half))
            }

            // مؤشر التشغيل الثابت في المنتصف
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .width(2.dp)
                    .fillMaxHeight()
                    .background(Color.White)
            )

            if (project.clips.isEmpty() && project.audios.isEmpty() && project.texts.isEmpty()) {
                Text(
                    "اضغط + لإضافة فيديو أو صور",
                    color = VMColors.TextDim,
                    fontSize = 13.sp,
                    modifier = Modifier.align(Alignment.Center).padding(top = 40.dp)
                )
            }
        }
    }
}

@Composable
private fun Ruler(contentDp: Dp, ppm: Float, maxMs: Long) {
    val steps = longArrayOf(1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 1800, 3600)
    var stepSec = steps.last()
    for (s in steps) {
        if (s * 1000L * ppm >= 70f) {
            stepSec = s
            break
        }
    }
    Canvas(modifier = Modifier.width(contentDp).height(22.dp)) {
        val paint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#9AA0B4")
            textSize = 10.sp.toPx()
            isAntiAlias = true
        }
        var s = 0L
        while (s * 1000L <= maxMs) {
            val x = s * 1000L * ppm
            drawLine(
                color = Color(0xFF5A6076),
                start = Offset(x, size.height - 8.dp.toPx()),
                end = Offset(x, size.height),
                strokeWidth = 1.dp.toPx()
            )
            drawIntoCanvas { it.nativeCanvas.drawText(formatTime(s * 1000L), x + 3.dp.toPx(), size.height - 9.dp.toPx(), paint) }
            // علامات صغيرة بين الأرقام
            val sub = stepSec * 1000L * ppm / 4f
            for (k in 1..3) {
                val sx = x + sub * k
                drawLine(
                    color = Color(0xFF3A3F52),
                    start = Offset(sx, size.height - 4.dp.toPx()),
                    end = Offset(sx, size.height),
                    strokeWidth = 1.dp.toPx()
                )
            }
            s += stepSec
        }
    }
}

@Composable
private fun ClipBlock(vm: EditorViewModel, c: VisualClip, ppm: Float) {
    val density = LocalDensity.current
    val selected = (vm.selection as? Selection.Clip)?.id == c.id
    val w = with(density) { (c.outMs * ppm).toDp() }.coerceAtLeast(18.dp)
    val shape = RoundedCornerShape(6.dp)

    Box(
        modifier = Modifier
            .padding(end = 1.dp)
            .width(w)
            .height(CLIP_H)
            .clip(shape)
            .background(VMColors.VideoTrack)
            .then(if (selected) Modifier.border(2.dp, VMColors.Accent, shape) else Modifier)
            .pointerInput(c.id) {
                detectTapGestures { vm.selection = Selection.Clip(c.id); vm.panel = null }
            }
    ) {
        val bmp = c.thumb
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .background(Color(0x99000000))
                .padding(horizontal = 4.dp, vertical = 1.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(formatTime(c.outMs), color = Color.White, fontSize = 10.sp)
            if (c.speed != 1f) Text("  x" + c.speed, color = VMColors.Accent, fontSize = 10.sp)
            if (c.muted && !c.isImage) {
                Icon(
                    Icons.Filled.VolumeOff,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.padding(start = 3.dp).size(11.dp)
                )
            }
        }
        if (selected) {
            EdgeHandle(
                modifier = Modifier.align(Alignment.CenterStart),
                key = c.id,
                ppm = ppm,
                onStart = { vm.checkpoint() },
                onDelta = { vm.resizeClipEdge(c.id, true, it) }
            )
            EdgeHandle(
                modifier = Modifier.align(Alignment.CenterEnd),
                key = c.id,
                ppm = ppm,
                onStart = { vm.checkpoint() },
                onDelta = { vm.resizeClipEdge(c.id, false, it) }
            )
        }
    }
}

@Composable
private fun EdgeHandle(
    modifier: Modifier,
    key: Long,
    ppm: Float,
    onStart: () -> Unit,
    onDelta: (Long) -> Unit
) {
    Box(
        modifier = modifier
            .width(14.dp)
            .fillMaxHeight()
            .background(VMColors.Accent)
            .pointerInput(key, ppm) {
                detectHorizontalDragGestures(
                    onDragStart = { onStart() },
                    onDragEnd = {},
                    onDragCancel = {},
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        onDelta((dx / ppm).toLong())
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.width(2.dp).height(14.dp).background(Color.Black.copy(alpha = 0.6f)))
    }
}

@Composable
private fun TrackBlock(
    x: Dp,
    y: Dp,
    width: Dp,
    height: Dp,
    color: Color,
    selected: Boolean,
    label: String,
    ppm: Float,
    key: Long,
    onTap: () -> Unit,
    onMove: (Long) -> Unit,
    onResizeStart: (Long) -> Unit,
    onResizeEnd: (Long) -> Unit,
    onDragStart: () -> Unit
) {
    val shape = RoundedCornerShape(5.dp)
    Box(
        modifier = Modifier
            .offset(x = x, y = y)
            .width(width.coerceAtLeast(14.dp))
            .height(height)
            .clip(shape)
            .background(color)
            .then(if (selected) Modifier.border(2.dp, VMColors.Accent, shape) else Modifier)
            .pointerInput(key) { detectTapGestures { onTap() } }
            .pointerInput(key, ppm, selected) {
                if (selected) {
                    detectHorizontalDragGestures(
                        onDragStart = { onDragStart() },
                        onDragEnd = {},
                        onDragCancel = {},
                        onHorizontalDrag = { change, dx ->
                            change.consume()
                            onMove((dx / ppm).toLong())
                        }
                    )
                }
            }
    ) {
        Text(
            label,
            color = Color.White,
            fontSize = 10.sp,
            maxLines = 1,
            modifier = Modifier.align(Alignment.CenterStart).padding(horizontal = 16.dp)
        )
        if (selected) {
            EdgeHandle(
                modifier = Modifier.align(Alignment.CenterStart),
                key = key,
                ppm = ppm,
                onStart = onDragStart,
                onDelta = onResizeStart
            )
            EdgeHandle(
                modifier = Modifier.align(Alignment.CenterEnd),
                key = key,
                ppm = ppm,
                onStart = onDragStart,
                onDelta = onResizeEnd
            )
        }
    }
}
