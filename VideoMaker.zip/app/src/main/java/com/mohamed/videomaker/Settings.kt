package com.mohamed.videomaker

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

enum class ThemeMode(val label: String) {
    DARK("داكن"),
    AMOLED("أسود"),
    LIGHT("فاتح")
}

enum class AccentOption(val label: String, val color: Color, val dim: Color) {
    TEAL("فيروزي", Color(0xFF19D3C5), Color(0xFF0E7F78)),
    VIOLET("بنفسجي", Color(0xFF9B7BFF), Color(0xFF5B43B5)),
    BLUE("أزرق", Color(0xFF4C9AFF), Color(0xFF2A5FAE)),
    ORANGE("برتقالي", Color(0xFFFF9F43), Color(0xFFB36A1F)),
    PINK("وردي", Color(0xFFFF5C9D), Color(0xFFB02F68)),
    GREEN("أخضر", Color(0xFF5BD36B), Color(0xFF2F8A3B))
}

/** إعدادات التطبيق المحفوظة (اللغة، الشكل، التصدير الافتراضي). حالة Compose فتتحدث الواجهة فورًا. */
object AppSettings {
    var lang by mutableStateOf("ar")
    var mode by mutableStateOf(ThemeMode.DARK)
    var accent by mutableStateOf(AccentOption.TEAL)
    var exportConfig by mutableStateOf(ExportConfig())
    var imageSeconds by mutableStateOf(5)
    var onboarded by mutableStateOf(true)

    val isArabic: Boolean get() = lang == "ar"

    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        val p = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
        prefs = p
        try {
            lang = p.getString("lang", null) ?: defaultLang()
            mode = ThemeMode.valueOf(p.getString("mode", ThemeMode.DARK.name) ?: ThemeMode.DARK.name)
            accent = AccentOption.valueOf(p.getString("accent", AccentOption.TEAL.name) ?: AccentOption.TEAL.name)
            imageSeconds = p.getInt("imageSeconds", 5)
            onboarded = p.getBoolean("onboarded", false)
            exportConfig = ExportConfig(
                res = ExportRes.valueOf(p.getString("res", ExportRes.R720.name) ?: ExportRes.R720.name),
                fps = p.getInt("fps", 30),
                quality = ExportQuality.valueOf(p.getString("quality", ExportQuality.MEDIUM.name) ?: ExportQuality.MEDIUM.name)
            )
        } catch (e: Exception) {
            // قيم تالفة: نرجع للافتراضي
        }
    }

    private fun defaultLang(): String =
        if (java.util.Locale.getDefault().language == "ar") "ar" else "en"

    fun save() {
        prefs?.edit()
            ?.putInt("imageSeconds", imageSeconds)
            ?.putBoolean("onboarded", onboarded)
            ?.putString("lang", lang)
            ?.putString("mode", mode.name)
            ?.putString("accent", accent.name)
            ?.putString("res", exportConfig.res.name)
            ?.putInt("fps", exportConfig.fps)
            ?.putString("quality", exportConfig.quality.name)
            ?.apply()
    }
}
