package com.mohamed.videomaker

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** شعار التطبيق مرسوم بالكود (نفس تصميم أيقونة التطبيق). */
@Composable
fun LogoMark(size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val s = this.size.width / 108f
        // الخلفية
        drawRoundRect(
            brush = Brush.linearGradient(
                listOf(VMColors.Accent, Color(0xFF6D5BFF)),
                start = Offset(0f, 0f),
                end = Offset(this.size.width, this.size.height)
            ),
            cornerRadius = CornerRadius(26f * s, 26f * s)
        )
        // شاشة الفيديو
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(24f * s, 32f * s),
            size = Size(60f * s, 38f * s),
            cornerRadius = CornerRadius(6f * s, 6f * s)
        )
        // زر التشغيل
        val tri = Path().apply {
            moveTo(48f * s, 42f * s)
            lineTo(48f * s, 60f * s)
            lineTo(66f * s, 51f * s)
            close()
        }
        drawPath(tri, Color(0xFF101319))
        // موجة الصوت
        val bars = listOf(80f to 6f, 77f to 12f, 74f to 18f, 77f to 12f, 80f to 6f)
        for ((i, b) in bars.withIndex()) {
            drawRoundRect(
                color = Color.White,
                topLeft = Offset((36f + i * 8f) * s, b.first * s),
                size = Size(4f * s, b.second * s),
                cornerRadius = CornerRadius(2f * s, 2f * s)
            )
        }
    }
}

private data class Feature(val icon: ImageVector, val label: String)

@Composable
fun HomeScreen(vm: EditorViewModel, onStart: () -> Unit, onSettings: () -> Unit) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isNotEmpty()) {
            onStart()
            vm.addMedia(uris)
        }
    }
    val features = listOf(
        Feature(Icons.Filled.VideoLibrary, "فيديو وصور"),
        Feature(Icons.Filled.MusicNote, "صوت وموسيقى"),
        Feature(Icons.Filled.TextFields, "نصوص وملصقات"),
        Feature(Icons.Filled.AutoAwesome, "فلاتر وحركة"),
        Feature(Icons.Filled.Speed, "تحكم بالسرعة"),
        Feature(Icons.Filled.FileDownload, "تصدير حتى 1080p")
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(VMColors.Accent.copy(alpha = 0.16f), VMColors.Bg, VMColors.Bg)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth()) {
                Spacer(Modifier.weight(1f))
                IconBtn(Icons.Filled.Settings, "الإعدادات", onClick = onSettings)
            }
            Spacer(Modifier.height(28.dp))
            LogoMark(112.dp)
            Spacer(Modifier.height(20.dp))
            Text("صانع الفيديو", color = VMColors.Text, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                "مونتاج كامل مجاني بدون علامة مائية ولا اشتراك",
                color = VMColors.TextDim,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(32.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.horizontalGradient(listOf(VMColors.Accent, VMColors.Accent.copy(alpha = 0.8f))))
                    .clickable {
                        pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    }
                    .padding(vertical = 17.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(24.dp))
                Spacer(Modifier.size(8.dp))
                Text("مشروع جديد", color = Color.Black, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, VMColors.Surface3, RoundedCornerShape(18.dp))
                    .clickable { onStart() }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("ابدأ بمشروع فاضي", color = VMColors.Text, fontSize = 15.sp)
            }
            Spacer(Modifier.height(32.dp))
            for (row in features.chunked(3)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    for (f in row) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(VMColors.Surface2)
                                .padding(vertical = 14.dp, horizontal = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(f.icon, contentDescription = null, tint = VMColors.Accent, modifier = Modifier.size(26.dp))
                            Text(f.label, color = VMColors.Text, fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }
    }
}
