package com.mohamed.videomaker

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.ColorMatrix as ComposeColorMatrix
import java.util.Locale

private fun pct(v: Float): String = String.format(Locale.US, "%d%%", (v * 100).toInt())
private fun secText(ms: Long): String = String.format(Locale.US, "%.1f ث", ms / 1000f)

@Composable
fun PanelHost(vm: EditorViewModel, panel: Panel, onClose: () -> Unit, onRequestRecord: () -> Unit) {
    val clip = vm.selectedClip()
    val audio = vm.selectedAudio()
    val text = vm.selectedText()
    when (panel) {
        Panel.TRIM_IMAGE -> if (clip != null) DurationPanel(vm, clip, onClose)
        Panel.TRIM -> {
            if (clip != null && !clip.isImage) ClipTrimPanel(vm, clip, onClose)
            else if (audio != null) AudioTrimPanel(vm, audio, onClose)
        }
        Panel.SPEED -> if (clip != null) SpeedPanel(vm, clip, onClose)
        Panel.VOLUME -> if (clip != null) ClipVolumePanel(vm, clip, onClose)
        Panel.FILTER -> if (clip != null) FilterPanel(vm, clip, onClose)
        Panel.ADJUST -> if (clip != null) AdjustPanel(vm, clip, onClose)
        Panel.ANIM -> if (clip != null) AnimPanel(vm, clip, onClose)
        Panel.AUDIO_VOLUME -> if (audio != null) AudioVolumePanel(vm, audio, onClose)
        Panel.AUDIO_FADE -> if (audio != null) AudioFadePanel(vm, audio, onClose)
        Panel.TEXT_EDIT -> if (text != null) TextEditPanel(vm, text, onClose)
        Panel.TEXT_STYLE -> if (text != null) TextStylePanel(vm, text, onClose)
        Panel.STICKERS -> StickersPanel(vm, onClose)
        Panel.ASPECT -> AspectPanel(vm, onClose)
        Panel.RECORD -> RecordPanel(vm, onClose, onRequestRecord)
    }
}

// ---------------------------------------------------------------- مدة الصورة

@Composable
private fun DurationPanel(vm: EditorViewModel, clip: VisualClip, onClose: () -> Unit) {
    var min by remember(clip.id) { mutableStateOf((clip.imageMs / 60000L).toString()) }
    var sec by remember(clip.id) { mutableStateOf(((clip.imageMs % 60000L) / 1000L).toString()) }
    LaunchedEffect(clip.imageMs) {
        min = (clip.imageMs / 60000L).toString()
        sec = ((clip.imageMs % 60000L) / 1000L).toString()
    }
    PanelFrame("مدة عرض الصورة: " + formatTime(clip.imageMs), onClose) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = min,
                onValueChange = { v -> min = v.filter { it.isDigit() }.take(4) },
                label = { Text("دقائق") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = sec,
                onValueChange = { v -> sec = v.filter { it.isDigit() }.take(4) },
                label = { Text("ثواني") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            SmallButton("تطبيق", accent = true) {
                val ms = (min.toLongOrNull() ?: 0L) * 60000L + (sec.toLongOrNull() ?: 0L) * 1000L
                vm.setImageDuration(clip.id, ms)
            }
        }
        val quick = listOf(3, 5, 10, 30, 60, 180, 300, 600)
        ChipRow(
            items = quick,
            selected = -1,
            label = { if (it < 60) "$it ث" else "${it / 60} د" },
            onSelect = { vm.setImageDuration(clip.id, it * 1000L) }
        )
        if (vm.project.audios.isNotEmpty()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("طول الصوت: " + formatTime(vm.project.audioEndMs), color = VMColors.TextDim, fontSize = 12.sp)
                SmallButton("مطابقة طول الصوت", accent = true) { vm.matchAudioLength(clip.id) }
            }
        }
    }
}

// ---------------------------------------------------------------- السرعة

@Composable
private fun SpeedPanel(vm: EditorViewModel, clip: VisualClip, onClose: () -> Unit) {
    val supported = remember { speedVideoEffect(1.5f) != null }
    PanelFrame("سرعة المقطع", onClose) {
        EditSlider(
            label = "السرعة",
            value = clip.speed,
            range = 0.25f..4f,
            valueText = String.format(Locale.US, "x%.2f", clip.speed),
            onStart = { vm.checkpoint() },
            onChange = { v ->
                val s = (Math.round(v * 20f) / 20f).coerceIn(0.25f, 4f)
                vm.updateClip(clip.id, false) { it.copy(speed = s) }
            }
        )
        ChipRow(
            items = listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f),
            selected = clip.speed,
            label = { "x$it" },
            onSelect = { s -> vm.updateClip(clip.id) { it.copy(speed = s) } }
        )
        if (!supported) {
            Text(
                "تغيير السرعة غير مدعوم في إصدار المكتبة الحالي للتصدير (يظهر في المعاينة فقط).",
                color = VMColors.Danger,
                fontSize = 11.sp
            )
        }
    }
}

// ---------------------------------------------------------------- الصوت

@Composable
private fun ClipVolumePanel(vm: EditorViewModel, clip: VisualClip, onClose: () -> Unit) {
    PanelFrame("صوت المقطع", onClose) {
        EditSlider(
            label = "مستوى الصوت",
            value = clip.volume,
            range = 0f..2f,
            valueText = pct(clip.volume),
            onStart = { vm.checkpoint() },
            onChange = { v -> vm.updateClip(clip.id, false) { it.copy(volume = v, muted = false) } }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("كتم", clip.muted) { vm.updateClip(clip.id) { it.copy(muted = !it.muted) } }
            Chip("100%", false) { vm.updateClip(clip.id) { it.copy(volume = 1f, muted = false) } }
        }
        Text("المعاينة تتوقف عند 100%، والزيادة تظهر في الملف النهائي.", color = VMColors.TextDim, fontSize = 11.sp)
    }
}

@Composable
private fun AudioVolumePanel(vm: EditorViewModel, a: AudioItem, onClose: () -> Unit) {
    PanelFrame("مستوى الصوت", onClose) {
        EditSlider(
            label = a.name,
            value = a.volume,
            range = 0f..2f,
            valueText = pct(a.volume),
            onStart = { vm.checkpoint() },
            onChange = { v -> vm.updateAudio(a.id, false) { it.copy(volume = v) } }
        )
        Text("المعاينة تتوقف عند 100%، والزيادة تظهر في الملف النهائي.", color = VMColors.TextDim, fontSize = 11.sp)
    }
}

@Composable
private fun AudioFadePanel(vm: EditorViewModel, a: AudioItem, onClose: () -> Unit) {
    val maxFade = (a.lengthMs / 2).coerceAtMost(15_000L).toFloat().coerceAtLeast(500f)
    PanelFrame("تلاشي الصوت", onClose) {
        EditSlider(
            label = "تلاشي عند البداية",
            value = a.fadeInMs.toFloat(),
            range = 0f..maxFade,
            valueText = secText(a.fadeInMs),
            onStart = { vm.checkpoint() },
            onChange = { v -> vm.updateAudio(a.id, false) { it.copy(fadeInMs = v.toLong()) } }
        )
        EditSlider(
            label = "تلاشي عند النهاية",
            value = a.fadeOutMs.toFloat(),
            range = 0f..maxFade,
            valueText = secText(a.fadeOutMs),
            onStart = { vm.checkpoint() },
            onChange = { v -> vm.updateAudio(a.id, false) { it.copy(fadeOutMs = v.toLong()) } }
        )
    }
}

// ---------------------------------------------------------------- الفلاتر والتعديل

@Composable
private fun FilterPanel(vm: EditorViewModel, clip: VisualClip, onClose: () -> Unit) {
    PanelFrame("الفلاتر", onClose) {
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            for (f in ClipFilter.entries) {
                val sel = clip.filter == f
                val m = clipColorMatrix(clip.copy(filter = f, adjust = Adjust()))
                Column(
                    modifier = Modifier.clickable { vm.updateClip(clip.id) { it.copy(filter = f) } },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(VMColors.Surface3)
                            .border(if (sel) 3.dp else 0.dp, if (sel) VMColors.Accent else Color.Transparent, RoundedCornerShape(8.dp))
                    ) {
                        val bmp = clip.thumb
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = f.label,
                                contentScale = ContentScale.Crop,
                                colorFilter = if (m != null) ColorFilter.colorMatrix(ComposeColorMatrix(m.array)) else null,
                                modifier = Modifier.size(64.dp)
                            )
                        }
                    }
                    Text(f.label, color = if (sel) VMColors.Accent else VMColors.Text, fontSize = 11.sp)
                }
            }
        }
        if (vm.project.clips.size > 1) {
            SmallButton("تطبيق على كل المقاطع") { vm.applyFilterToAll(clip.filter) }
        }
    }
}

@Composable
private fun AdjustPanel(vm: EditorViewModel, clip: VisualClip, onClose: () -> Unit) {
    val a = clip.adjust
    PanelFrame("تعديل الألوان", onClose) {
        Column(Modifier.heightIn(max = 230.dp).verticalScroll(rememberScrollState())) {
            EditSlider("السطوع", a.brightness, -1f..1f, pct(a.brightness), { vm.checkpoint() }) { v ->
                vm.updateClip(clip.id, false) { it.copy(adjust = it.adjust.copy(brightness = v)) }
            }
            EditSlider("التباين", a.contrast, -1f..1f, pct(a.contrast), { vm.checkpoint() }) { v ->
                vm.updateClip(clip.id, false) { it.copy(adjust = it.adjust.copy(contrast = v)) }
            }
            EditSlider("التشبع", a.saturation, -1f..1f, pct(a.saturation), { vm.checkpoint() }) { v ->
                vm.updateClip(clip.id, false) { it.copy(adjust = it.adjust.copy(saturation = v)) }
            }
            EditSlider("الدفء", a.warmth, -1f..1f, pct(a.warmth), { vm.checkpoint() }) { v ->
                vm.updateClip(clip.id, false) { it.copy(adjust = it.adjust.copy(warmth = v)) }
            }
        }
        SmallButton("إعادة ضبط", enabled = !a.isNeutral) {
            vm.updateClip(clip.id) { it.copy(adjust = Adjust()) }
        }
    }
}

@Composable
private fun AnimPanel(vm: EditorViewModel, clip: VisualClip, onClose: () -> Unit) {
    PanelFrame("الحركة والانتقال", onClose) {
        ChipRow(
            items = ClipAnim.entries.toList(),
            selected = clip.anim,
            label = { it.label },
            onSelect = { an -> vm.updateClip(clip.id) { it.copy(anim = an) } }
        )
        Text(
            "التلاشي والتكبير يتطبقوا في أول وآخر المقطع، والتقريب/الإبعاد البطيء على طول المقطع.",
            color = VMColors.TextDim,
            fontSize = 11.sp
        )
        if (vm.project.clips.size > 1) {
            SmallButton("تطبيق على كل المقاطع") { vm.applyAnimToAll(clip.anim) }
        }
    }
}

// ---------------------------------------------------------------- النصوص

private val TEXT_COLORS = listOf(
    0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFFD54F.toInt(), 0xFFFF5252.toInt(),
    0xFF69F0AE.toInt(), 0xFF40C4FF.toInt(), 0xFFFF80AB.toInt(), 0xFFFFAB40.toInt(),
    0xFFB388FF.toInt(), 0xFFFFD700.toInt()
)

private val BG_COLORS = listOf(
    0x00000000, 0x99000000.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt(),
    0xCC1B5E20.toInt(), 0xCC0D47A1.toInt(), 0xCCB71C1C.toInt(), 0xCC4A148C.toInt()
)

@Composable
private fun TextEditPanel(vm: EditorViewModel, item: TextItem, onClose: () -> Unit) {
    var text by remember(item.id) { mutableStateOf(item.text) }
    LaunchedEffect(item.id) { vm.checkpoint() }
    PanelFrame("تعديل النص", onClose) {
        OutlinedTextField(
            value = text,
            onValueChange = { v ->
                text = v
                vm.updateText(item.id, false) { it.copy(text = v) }
            },
            label = { Text("النص") },
            maxLines = 3,
            modifier = Modifier.fillMaxWidth()
        )
        ChipRow(
            items = TextFont.entries.toList(),
            selected = item.font,
            label = { it.label },
            onSelect = { f -> vm.updateText(item.id) { it.copy(font = f) } }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("عريض", item.bold) { vm.updateText(item.id) { it.copy(bold = !it.bold) } }
            Chip("مائل", item.italic) { vm.updateText(item.id) { it.copy(italic = !it.italic) } }
            Chip("تلاشي", item.anim == TextAnim.FADE) {
                vm.updateText(item.id) { it.copy(anim = if (it.anim == TextAnim.FADE) TextAnim.NONE else TextAnim.FADE) }
            }
        }
    }
}

@Composable
private fun TextStylePanel(vm: EditorViewModel, item: TextItem, onClose: () -> Unit) {
    PanelFrame("نمط النص", onClose) {
        Column(
            modifier = Modifier.heightIn(max = 250.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("لون النص", color = VMColors.TextDim, fontSize = 12.sp)
            ColorSwatches(TEXT_COLORS, item.color) { c -> vm.updateText(item.id) { it.copy(color = c) } }
            Text("الخلفية", color = VMColors.TextDim, fontSize = 12.sp)
            ColorSwatches(BG_COLORS, item.bgColor) { c -> vm.updateText(item.id) { it.copy(bgColor = c) } }
            EditSlider("الحجم", item.sizeFrac, 0.02f..0.4f, pct(item.sizeFrac), { vm.checkpoint() }) { v ->
                vm.updateText(item.id, false) { it.copy(sizeFrac = v) }
            }
            EditSlider("الدوران", item.rotation, -180f..180f, "${item.rotation.toInt()}°", { vm.checkpoint() }) { v ->
                vm.updateText(item.id, false) { it.copy(rotation = v) }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("يبدأ " + formatTimeTenths(item.startMs) + " — يدوم " + secText(item.durationMs), color = VMColors.TextDim, fontSize = 11.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton("ابدأ من المؤشر") {
                    val t = vm.engine.positionMs
                    vm.updateText(item.id) { it.copy(startMs = t) }
                }
                SmallButton("انتهِ عند المؤشر", enabled = vm.engine.positionMs > item.startMs + 300L) {
                    val t = vm.engine.positionMs
                    vm.updateText(item.id) { it.copy(durationMs = (t - it.startMs).coerceAtLeast(300L)) }
                }
            }
            Text("اسحب النص في المعاينة لتحريكه، واستخدم إصبعين للتكبير والتدوير.", color = VMColors.TextDim, fontSize = 11.sp)
        }
    }
}

private val EMOJIS = listOf(
    "❤️", "⭐", "🌙", "☪️", "🕌", "📿", "🤲", "✨", "🌹", "🔥",
    "👍", "😍", "😂", "🎉", "🌿", "🌸", "☀️", "⚡", "💎", "👑",
    "🕋", "🌟", "💫", "🎵", "📖", "🕊️", "🌴", "🌊", "⛅", "🎬",
    "🏆", "💯", "🙏", "😎", "🥰", "🌺", "🍃", "🦋", "🌈", "💚"
)

@Composable
private fun StickersPanel(vm: EditorViewModel, onClose: () -> Unit) {
    PanelFrame("ملصقات", onClose) {
        Column(
            modifier = Modifier.heightIn(max = 190.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            for (row in EMOJIS.chunked(8)) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (e in row) {
                        Box(
                            modifier = Modifier
                                .width(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { vm.addSticker(e) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(e, fontSize = 26.sp)
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- مقاس + تسجيل

@Composable
private fun AspectPanel(vm: EditorViewModel, onClose: () -> Unit) {
    PanelFrame("أبعاد الفيديو", onClose) {
        ChipRow(
            items = AspectOption.entries.toList(),
            selected = vm.project.aspect,
            label = { it.label },
            onSelect = { vm.setAspect(it) }
        )
        Text(
            "16:9 لليوتيوب · 9:16 للريلز وتيك توك · 1:1 و4:5 لإنستجرام.",
            color = VMColors.TextDim,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun RecordPanel(vm: EditorViewModel, onClose: () -> Unit, onRequestRecord: () -> Unit) {
    PanelFrame("تسجيل صوتي", {
        if (vm.recording) vm.stopRecording()
        onClose()
    }) {
        if (vm.recording) {
            Text("● جاري التسجيل... تكلّم الآن", color = VMColors.Danger, fontSize = 14.sp)
            SmallButton("■ إيقاف وحفظ", accent = true) {
                vm.stopRecording()
                onClose()
            }
        } else {
            Text(
                "يبدأ التسجيل من موضع المؤشر ويشغّل المعاينة أثناءه. استخدم سماعات لتجنب الصدى.",
                color = VMColors.TextDim,
                fontSize = 12.sp
            )
            SmallButton("● ابدأ التسجيل", accent = true) { onRequestRecord() }
        }
    }
}

// ---------------------------------------------------------------- قص الفيديو والصوت

private const val MIN_CUT = 200L

@Composable
private fun TrimRow(
    label: String,
    timeMs: Long,
    onMinus: () -> Unit,
    onPlus: () -> Unit,
    onHere: () -> Unit,
    onSet: (Long) -> Unit
) {
    var show by remember { mutableStateOf(false) }
    var min by remember { mutableStateOf("") }
    var sec by remember { mutableStateOf("") }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Column(
            Modifier
                .width(84.dp)
                .clip(RoundedCornerShape(8.dp))
                .clickable {
                    min = (timeMs / 60000L).toString()
                    sec = String.format(Locale.US, "%.1f", (timeMs % 60000L) / 1000f)
                    show = true
                }
                .padding(4.dp)
        ) {
            Text(label, color = VMColors.TextDim, fontSize = 11.sp)
            Text(formatTimeTenths(timeMs), color = VMColors.Accent, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        }
        SmallButton("−0.1") { onMinus() }
        SmallButton("+0.1") { onPlus() }
        SmallButton("من المؤشر") { onHere() }
    }
    if (show) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    val m = min.toLongOrNull() ?: 0L
                    val sc = sec.replace(',', '.').toFloatOrNull() ?: 0f
                    onSet(m * 60000L + (sc * 1000f).toLong())
                    show = false
                }) { Text("تطبيق") }
            },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { show = false }) { Text("إلغاء") } },
            title = { Text("اكتب الوقت بالضبط") },
            text = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = min,
                        onValueChange = { v -> min = v.filter { it.isDigit() }.take(4) },
                        label = { Text("دقائق") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = sec,
                        onValueChange = { v -> sec = v.filter { it.isDigit() || it == '.' || it == ',' }.take(6) },
                        label = { Text("ثواني") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ClipTrimPanel(vm: EditorViewModel, clip: VisualClip, onClose: () -> Unit) {
    var dragging by remember { mutableStateOf(false) }
    val id = clip.id
    fun setRange(s: Long, e: Long, startMoved: Boolean) {
        val src = clip.sourceMs
        val ns = s.coerceIn(0L, src - MIN_CUT)
        val ne = e.coerceIn(ns + MIN_CUT, src)
        vm.updateClip(id, false) { it.copy(trimStartMs = ns, trimEndMs = ne) }
        val c = vm.clipById(id) ?: return
        val base = vm.project.startOf(id)
        vm.engine.seekTo(if (startMoved) base else (base + c.outMs - 150L).coerceAtLeast(base))
    }
    PanelFrame("قص المقطع", onClose) {
        Text(
            "المقطع الأصلي " + formatTime(clip.sourceMs) + " · المحدد " + formatTimeTenths(clip.trimEndMs - clip.trimStartMs),
            color = VMColors.TextDim,
            fontSize = 12.sp
        )
        RangeSlider(
            value = clip.trimStartMs.toFloat()..clip.trimEndMs.toFloat(),
            onValueChange = { r ->
                if (!dragging) {
                    dragging = true
                    vm.checkpoint()
                }
                val s = r.start.toLong()
                val e = r.endInclusive.toLong()
                if (e - s >= MIN_CUT) setRange(s, e, s != clip.trimStartMs)
            },
            onValueChangeFinished = { dragging = false },
            valueRange = 0f..clip.sourceMs.toFloat().coerceAtLeast(MIN_CUT * 2f)
        )
        Column(Modifier.heightIn(max = 170.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            TrimRow("البداية", clip.trimStartMs,
                onMinus = { vm.checkpoint(); setRange(clip.trimStartMs - 100L, clip.trimEndMs, true) },
                onPlus = { vm.checkpoint(); setRange(clip.trimStartMs + 100L, clip.trimEndMs, true) },
                onHere = {
                    val local = (vm.engine.positionMs - vm.project.startOf(id)).coerceIn(0L, clip.outMs)
                    vm.checkpoint()
                    setRange(clip.trimStartMs + (local * clip.speed).toLong(), clip.trimEndMs, true)
                },
                onSet = { t -> vm.checkpoint(); setRange(t, clip.trimEndMs, true) })
            TrimRow("النهاية", clip.trimEndMs,
                onMinus = { vm.checkpoint(); setRange(clip.trimStartMs, clip.trimEndMs - 100L, false) },
                onPlus = { vm.checkpoint(); setRange(clip.trimStartMs, clip.trimEndMs + 100L, false) },
                onHere = {
                    val local = (vm.engine.positionMs - vm.project.startOf(id)).coerceIn(0L, clip.outMs)
                    vm.checkpoint()
                    setRange(clip.trimStartMs, clip.trimStartMs + (local * clip.speed).toLong(), false)
                },
                onSet = { t -> vm.checkpoint(); setRange(clip.trimStartMs, t, false) })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton("تشغيل المقطع", accent = true) {
                    vm.engine.seekTo(vm.project.startOf(id))
                    vm.engine.play()
                }
                SmallButton("إعادة الأصل", enabled = clip.trimStartMs > 0L || clip.trimEndMs < clip.sourceMs) {
                    vm.checkpoint()
                    vm.updateClip(id, false) { it.copy(trimStartMs = 0L, trimEndMs = it.sourceMs) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AudioTrimPanel(vm: EditorViewModel, a: AudioItem, onClose: () -> Unit) {
    var dragging by remember { mutableStateOf(false) }
    val id = a.id
    fun setRange(s: Long, e: Long) {
        val cur = vm.audioById(id) ?: return
        val ns = s.coerceIn(0L, cur.sourceMs - MIN_CUT)
        val ne = e.coerceIn(ns + MIN_CUT, cur.sourceMs)
        val shift = ns - cur.trimStartMs
        // نحافظ على مكان باقي الصوت على التايم لاين (زي سحب الحافة)
        vm.updateAudio(id, false) { it.copy(trimStartMs = ns, trimEndMs = ne, startMs = (it.startMs + shift).coerceAtLeast(0L)) }
    }
    PanelFrame("قص الصوت", onClose) {
        Text(
            a.name + " · " + "المقطع الأصلي " + formatTime(a.sourceMs) + " · المحدد " + formatTimeTenths(a.trimEndMs - a.trimStartMs),
            color = VMColors.TextDim,
            fontSize = 12.sp,
            maxLines = 1
        )
        RangeSlider(
            value = a.trimStartMs.toFloat()..a.trimEndMs.toFloat(),
            onValueChange = { r ->
                if (!dragging) {
                    dragging = true
                    vm.checkpoint()
                }
                val s = r.start.toLong()
                val e = r.endInclusive.toLong()
                if (e - s >= MIN_CUT) setRange(s, e)
            },
            onValueChangeFinished = { dragging = false },
            valueRange = 0f..a.sourceMs.toFloat().coerceAtLeast(MIN_CUT * 2f)
        )
        Column(Modifier.heightIn(max = 170.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            TrimRow("البداية", a.trimStartMs,
                onMinus = { vm.checkpoint(); setRange(a.trimStartMs - 100L, a.trimEndMs) },
                onPlus = { vm.checkpoint(); setRange(a.trimStartMs + 100L, a.trimEndMs) },
                onHere = {
                    val local = (vm.engine.positionMs - a.startMs).coerceIn(0L, a.lengthMs)
                    vm.checkpoint()
                    setRange(a.trimStartMs + local, a.trimEndMs)
                },
                onSet = { t -> vm.checkpoint(); setRange(t, a.trimEndMs) })
            TrimRow("النهاية", a.trimEndMs,
                onMinus = { vm.checkpoint(); setRange(a.trimStartMs, a.trimEndMs - 100L) },
                onPlus = { vm.checkpoint(); setRange(a.trimStartMs, a.trimEndMs + 100L) },
                onHere = {
                    val local = (vm.engine.positionMs - a.startMs).coerceIn(0L, a.lengthMs)
                    vm.checkpoint()
                    setRange(a.trimStartMs, a.trimStartMs + local)
                },
                onSet = { t -> vm.checkpoint(); setRange(a.trimStartMs, t) })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton("تشغيل المقطع", accent = true) {
                    val cur = vm.audioById(id) ?: return@SmallButton
                    vm.engine.seekTo(cur.startMs)
                    vm.engine.play()
                }
                SmallButton("إعادة الأصل", enabled = a.trimStartMs > 0L || a.trimEndMs < a.sourceMs) {
                    vm.checkpoint()
                    vm.updateAudio(id, false) { it.copy(trimStartMs = 0L, trimEndMs = it.sourceMs) }
                }
            }
        }
    }
}
