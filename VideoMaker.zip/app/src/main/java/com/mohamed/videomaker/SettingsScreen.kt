package com.mohamed.videomaker

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.vector.ImageVector
import android.content.Intent
import android.net.Uri
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.activity.compose.BackHandler
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(VMColors.Surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, color = VMColors.Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

private const val PLAY_URL = "https://play.google.com/store/apps/details?id=com.mohamed.videomaker"

fun privacyText(): String =
    if (AppSettings.isArabic) {
        "صانع الفيديو لا يجمع أي بيانات شخصية ولا يرسل أي معلومات خارج جهازك.\n\n" +
            "• كل عمليات المونتاج والتصدير تتم على جهازك فقط، والتطبيق لا يطلب إذن الإنترنت.\n" +
            "• الميكروفون: يُستخدم فقط عند ضغطك زر التسجيل الصوتي، ويُحفظ التسجيل داخل مشروعك على الجهاز.\n" +
            "• الصور والفيديوهات والصوتيات: تختارها بنفسك عبر منتقي الوسائط في النظام، ولا يصل التطبيق لباقي ملفاتك.\n" +
            "• المشاريع تُحفظ داخل مساحة التطبيق على جهازك، وتُحذف بحذف المشروع أو التطبيق.\n" +
            "• لا توجد إعلانات ولا أدوات تحليل ولا تتبع.\n" +
            "• الفيديوهات المصدّرة تُحفظ في معرض جهازك داخل مجلد VideoMaker."
    } else {
        "Video Maker does not collect any personal data and never sends information off your device.\n\n" +
            "• All editing and exporting happens on your device only. The app does not request internet permission.\n" +
            "• Microphone: used only when you tap the record button; the recording is stored inside your project on the device.\n" +
            "• Photos, videos and audio: you pick them yourself with the system media picker; the app cannot see your other files.\n" +
            "• Projects are stored in the app's private storage and are removed when you delete the project or the app.\n" +
            "• No ads, no analytics, no tracking.\n" +
            "• Exported videos are saved to your gallery in the VideoMaker folder."
    }

@Composable
private fun LinkRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Icon(icon, contentDescription = null, tint = VMColors.Accent, modifier = Modifier.size(22.dp))
        Text(label, color = VMColors.Text, fontSize = 14.sp)
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var showPrivacy by remember { mutableStateOf(false) }
    BackHandler { onBack() }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(VMColors.Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBtn(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", onClick = onBack)
            Spacer(Modifier.size(8.dp))
            Text("الإعدادات", color = VMColors.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Section("اللغة") {
                ChipRow(listOf("ar", "en"), AppSettings.lang, { if (it == "ar") "العربية" else "English" }) {
                    AppSettings.lang = it
                    AppSettings.save()
                }
            }
            Section("المظهر") {
                ChipRow(ThemeMode.entries.toList(), AppSettings.mode, { it.label }) {
                    AppSettings.mode = it
                    AppSettings.save()
                }
                Text("لون التطبيق", color = VMColors.TextDim, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    for (a in AccentOption.entries) {
                        val sel = AppSettings.accent == a
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(a.color)
                                .border(if (sel) 3.dp else 0.dp, if (sel) VMColors.Text else Color.Transparent, CircleShape)
                                .clickable {
                                    AppSettings.accent = a
                                    AppSettings.save()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (sel) Icon(Icons.Filled.Check, contentDescription = a.label, tint = Color.Black, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
            Section("التصدير الافتراضي") {
                val cfg = AppSettings.exportConfig
                Text("الدقة", color = VMColors.TextDim, fontSize = 12.sp)
                ChipRow(ExportRes.entries.toList(), cfg.res, { it.label }) {
                    AppSettings.exportConfig = cfg.copy(res = it)
                    AppSettings.save()
                }
                Text("معدل الإطارات", color = VMColors.TextDim, fontSize = 12.sp)
                ChipRow(listOf(24, 30, 60), cfg.fps, { "$it fps" }) {
                    AppSettings.exportConfig = cfg.copy(fps = it)
                    AppSettings.save()
                }
                Text("الجودة", color = VMColors.TextDim, fontSize = 12.sp)
                ChipRow(ExportQuality.entries.toList(), cfg.quality, { it.label }) {
                    AppSettings.exportConfig = cfg.copy(quality = it)
                    AppSettings.save()
                }
            }
            Section("الاستخدام") {
                Text("مدة الصورة الافتراضية", color = VMColors.TextDim, fontSize = 12.sp)
                ChipRow(listOf(3, 5, 10, 15, 30), AppSettings.imageSeconds, { "$it ث" }) {
                    AppSettings.imageSeconds = it
                    AppSettings.save()
                }
            }
            Section("عن التطبيق") {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    LogoMark(56.dp)
                    Column {
                        Text("صانع الفيديو", color = VMColors.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("الإصدار 2.2", color = VMColors.TextDim, fontSize = 12.sp)
                    }
                }
                Text(
                    "تطبيق مونتاج مجاني بالكامل: بدون علامة مائية، وبدون اشتراكات، وبدون إعلانات.",
                    color = VMColors.TextDim,
                    fontSize = 12.sp
                )
                LinkRow(Icons.Filled.PrivacyTip, "سياسة الخصوصية") { showPrivacy = true }
                LinkRow(Icons.Filled.Share, "مشاركة التطبيق") {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, PLAY_URL)
                    }
                    context.startActivity(Intent.createChooser(send, tr("مشاركة التطبيق")))
                }
                LinkRow(Icons.Filled.Star, "قيّم التطبيق") {
                    try {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.mohamed.videomaker")))
                    } catch (e: Exception) {
                        try {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(PLAY_URL)))
                        } catch (e2: Exception) {
                        }
                    }
                }
            }
            Text("التغييرات بتتحفظ تلقائيًا.", color = VMColors.TextDim, fontSize = 11.sp)
            Spacer(Modifier.height(16.dp))
        }
        if (showPrivacy) {
            AlertDialog(
                onDismissRequest = { showPrivacy = false },
                confirmButton = { TextButton(onClick = { showPrivacy = false }) { Text("حسنًا") } },
                title = { Text("سياسة الخصوصية") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        Text(privacyText(), fontSize = 13.sp)
                    }
                }
            )
        }
    }
}
