package com.mohamed.videomaker

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** ألوان التطبيق. كل خاصية getter فتتغير فورًا مع إعدادات الشكل. */
object VMColors {
    private val m: ThemeMode get() = AppSettings.mode

    val Bg: Color
        get() = when (m) {
            ThemeMode.DARK -> Color(0xFF0E0F14)
            ThemeMode.AMOLED -> Color(0xFF000000)
            ThemeMode.LIGHT -> Color(0xFFF3F4F8)
        }
    val Surface: Color
        get() = when (m) {
            ThemeMode.DARK -> Color(0xFF181A22)
            ThemeMode.AMOLED -> Color(0xFF0B0B0E)
            ThemeMode.LIGHT -> Color(0xFFFFFFFF)
        }
    val Surface2: Color
        get() = when (m) {
            ThemeMode.DARK -> Color(0xFF232632)
            ThemeMode.AMOLED -> Color(0xFF16171C)
            ThemeMode.LIGHT -> Color(0xFFECEEF4)
        }
    val Surface3: Color
        get() = when (m) {
            ThemeMode.DARK -> Color(0xFF2E3242)
            ThemeMode.AMOLED -> Color(0xFF212329)
            ThemeMode.LIGHT -> Color(0xFFDDE0EA)
        }
    val Text: Color
        get() = if (m == ThemeMode.LIGHT) Color(0xFF14161C) else Color(0xFFF2F4F8)
    val TextDim: Color
        get() = if (m == ThemeMode.LIGHT) Color(0xFF5C6378) else Color(0xFF9AA0B4)
    val Danger: Color
        get() = if (m == ThemeMode.LIGHT) Color(0xFFD62B4B) else Color(0xFFFF5470)

    val Accent: Color get() = AppSettings.accent.color
    val AccentDim: Color get() = AppSettings.accent.dim

    val VideoTrack = Color(0xFF3A4A6B)
    val AudioTrack = Color(0xFF1F6F5C)
    val VoiceTrack = Color(0xFF7A4A8C)
    val TextTrack = Color(0xFFB8762B)
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (AppSettings.mode == ThemeMode.LIGHT) {
        lightColorScheme(
            primary = VMColors.Accent,
            onPrimary = Color.Black,
            secondary = VMColors.Accent,
            background = VMColors.Bg,
            onBackground = VMColors.Text,
            surface = VMColors.Surface,
            onSurface = VMColors.Text,
            surfaceVariant = VMColors.Surface2,
            onSurfaceVariant = VMColors.TextDim,
            error = VMColors.Danger
        )
    } else {
        darkColorScheme(
            primary = VMColors.Accent,
            onPrimary = Color.Black,
            secondary = VMColors.Accent,
            background = VMColors.Bg,
            onBackground = VMColors.Text,
            surface = VMColors.Surface,
            onSurface = VMColors.Text,
            surfaceVariant = VMColors.Surface2,
            onSurfaceVariant = VMColors.TextDim,
            error = VMColors.Danger
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
