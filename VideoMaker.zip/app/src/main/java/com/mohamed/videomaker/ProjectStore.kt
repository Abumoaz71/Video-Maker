package com.mohamed.videomaker

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ProjectMeta(
    val id: String,
    val name: String,
    val updated: Long,
    val totalMs: Long,
    val clipCount: Int,
    val thumb: File?
)

/** حفظ المشاريع كملفات JSON داخل مخزن التطبيق (تحفظ تلقائيًا وتفتح من الشاشة الرئيسية). */
object ProjectStore {

    private fun dir(ctx: Context): File = File(ctx.filesDir, "projects").also { it.mkdirs() }

    private inline fun <reified T : Enum<T>> enumOf(name: String?, def: T): T =
        try {
            if (name == null) def else enumValueOf<T>(name)
        } catch (e: Exception) {
            def
        }

    fun save(ctx: Context, id: String, name: String, p: Project, thumb: Bitmap?) {
        try {
            val root = JSONObject()
            root.put("id", id)
            root.put("name", name)
            root.put("updated", System.currentTimeMillis())
            root.put("totalMs", p.totalMs)
            root.put("clipCount", p.clips.size)
            root.put("aspect", p.aspect.name)

            val clips = JSONArray()
            for (c in p.clips) {
                clips.put(JSONObject().apply {
                    put("id", c.id)
                    put("uri", c.uri.toString())
                    put("isImage", c.isImage)
                    put("sourceMs", c.sourceMs)
                    put("trimStartMs", c.trimStartMs)
                    put("trimEndMs", c.trimEndMs)
                    put("imageMs", c.imageMs)
                    put("speed", c.speed.toDouble())
                    put("volume", c.volume.toDouble())
                    put("muted", c.muted)
                    put("filter", c.filter.name)
                    put("brightness", c.adjust.brightness.toDouble())
                    put("contrast", c.adjust.contrast.toDouble())
                    put("saturation", c.adjust.saturation.toDouble())
                    put("warmth", c.adjust.warmth.toDouble())
                    put("rotation", c.rotation)
                    put("flipH", c.flipH)
                    put("flipV", c.flipV)
                    put("fill", c.fill)
                    put("anim", c.anim.name)
                    put("srcWidth", c.srcWidth)
                    put("srcHeight", c.srcHeight)
                })
            }
            root.put("clips", clips)

            val audios = JSONArray()
            for (a in p.audios) {
                audios.put(JSONObject().apply {
                    put("id", a.id)
                    put("uri", a.uri.toString())
                    put("name", a.name)
                    put("sourceMs", a.sourceMs)
                    put("trimStartMs", a.trimStartMs)
                    put("trimEndMs", a.trimEndMs)
                    put("startMs", a.startMs)
                    put("volume", a.volume.toDouble())
                    put("fadeInMs", a.fadeInMs)
                    put("fadeOutMs", a.fadeOutMs)
                    put("kind", a.kind)
                })
            }
            root.put("audios", audios)

            val texts = JSONArray()
            for (t in p.texts) {
                texts.put(JSONObject().apply {
                    put("id", t.id)
                    put("text", t.text)
                    put("startMs", t.startMs)
                    put("durationMs", t.durationMs)
                    put("x", t.x.toDouble())
                    put("y", t.y.toDouble())
                    put("sizeFrac", t.sizeFrac.toDouble())
                    put("color", t.color)
                    put("bgColor", t.bgColor)
                    put("bold", t.bold)
                    put("italic", t.italic)
                    put("font", t.font.name)
                    put("anim", t.anim.name)
                    put("rotation", t.rotation.toDouble())
                    put("isSticker", t.isSticker)
                })
            }
            root.put("texts", texts)

            val tmp = File(dir(ctx), "$id.json.tmp")
            tmp.writeText(root.toString())
            tmp.renameTo(File(dir(ctx), "$id.json"))

            val tf = File(dir(ctx), "$id.jpg")
            if (thumb != null && !tf.exists()) {
                tf.outputStream().use { thumb.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            }
        } catch (e: Exception) {
            // الحفظ التلقائي لا يجب أن يوقف التطبيق
        }
    }

    fun list(ctx: Context): List<ProjectMeta> {
        val out = ArrayList<ProjectMeta>()
        val files = dir(ctx).listFiles { f -> f.name.endsWith(".json") } ?: return out
        for (f in files) {
            try {
                val o = JSONObject(f.readText())
                val id = o.getString("id")
                val tf = File(dir(ctx), "$id.jpg")
                out += ProjectMeta(
                    id = id,
                    name = o.optString("name", id),
                    updated = o.optLong("updated"),
                    totalMs = o.optLong("totalMs"),
                    clipCount = o.optInt("clipCount"),
                    thumb = if (tf.exists()) tf else null
                )
            } catch (e: Exception) {
                // ملف تالف: نتجاهله
            }
        }
        return out.sortedByDescending { it.updated }
    }

    /** يرجع المشروع (بدون صور مصغرة) واسمه. */
    fun load(ctx: Context, id: String): Pair<Project, String>? {
        return try {
            val o = JSONObject(File(dir(ctx), "$id.json").readText())
            val clips = ArrayList<VisualClip>()
            val ca = o.optJSONArray("clips") ?: JSONArray()
            for (i in 0 until ca.length()) {
                val c = ca.getJSONObject(i)
                val src = c.optLong("sourceMs")
                clips += VisualClip(
                    id = c.getLong("id"),
                    uri = Uri.parse(c.getString("uri")),
                    isImage = c.optBoolean("isImage"),
                    sourceMs = src,
                    trimStartMs = c.optLong("trimStartMs"),
                    trimEndMs = c.optLong("trimEndMs", src),
                    imageMs = c.optLong("imageMs", 5000L),
                    speed = c.optDouble("speed", 1.0).toFloat(),
                    volume = c.optDouble("volume", 1.0).toFloat(),
                    muted = c.optBoolean("muted"),
                    filter = enumOf(c.optString("filter"), ClipFilter.NONE),
                    adjust = Adjust(
                        c.optDouble("brightness", 0.0).toFloat(),
                        c.optDouble("contrast", 0.0).toFloat(),
                        c.optDouble("saturation", 0.0).toFloat(),
                        c.optDouble("warmth", 0.0).toFloat()
                    ),
                    rotation = c.optInt("rotation"),
                    flipH = c.optBoolean("flipH"),
                    flipV = c.optBoolean("flipV"),
                    fill = c.optBoolean("fill"),
                    anim = enumOf(c.optString("anim"), ClipAnim.NONE),
                    srcWidth = c.optInt("srcWidth"),
                    srcHeight = c.optInt("srcHeight")
                )
            }
            val audios = ArrayList<AudioItem>()
            val aa = o.optJSONArray("audios") ?: JSONArray()
            for (i in 0 until aa.length()) {
                val a = aa.getJSONObject(i)
                val src = a.optLong("sourceMs")
                audios += AudioItem(
                    id = a.getLong("id"),
                    uri = Uri.parse(a.getString("uri")),
                    name = a.optString("name"),
                    sourceMs = src,
                    trimStartMs = a.optLong("trimStartMs"),
                    trimEndMs = a.optLong("trimEndMs", src),
                    startMs = a.optLong("startMs"),
                    volume = a.optDouble("volume", 1.0).toFloat(),
                    fadeInMs = a.optLong("fadeInMs"),
                    fadeOutMs = a.optLong("fadeOutMs"),
                    kind = a.optInt("kind")
                )
            }
            val texts = ArrayList<TextItem>()
            val ta = o.optJSONArray("texts") ?: JSONArray()
            for (i in 0 until ta.length()) {
                val t = ta.getJSONObject(i)
                texts += TextItem(
                    id = t.getLong("id"),
                    text = t.optString("text"),
                    startMs = t.optLong("startMs"),
                    durationMs = t.optLong("durationMs", 4000L),
                    x = t.optDouble("x", 0.5).toFloat(),
                    y = t.optDouble("y", 0.8).toFloat(),
                    sizeFrac = t.optDouble("sizeFrac", 0.07).toFloat(),
                    color = t.optInt("color", 0xFFFFFFFF.toInt()),
                    bgColor = t.optInt("bgColor", 0x99000000.toInt()),
                    bold = t.optBoolean("bold", true),
                    italic = t.optBoolean("italic"),
                    font = enumOf(t.optString("font"), TextFont.SANS),
                    anim = enumOf(t.optString("anim"), TextAnim.FADE),
                    rotation = t.optDouble("rotation", 0.0).toFloat(),
                    isSticker = t.optBoolean("isSticker")
                )
            }
            val project = Project(
                clips = clips,
                audios = audios,
                texts = texts,
                aspect = enumOf(o.optString("aspect"), AspectOption.WIDE)
            )
            Pair(project, o.optString("name"))
        } catch (e: Exception) {
            null
        }
    }

    fun delete(ctx: Context, id: String) {
        File(dir(ctx), "$id.json").delete()
        File(dir(ctx), "$id.jpg").delete()
        cleanupMedia(ctx)
    }

    /** يمسح ملفات الوسائط المنسوخة داخل التطبيق ولا يستخدمها أي مشروع. */
    private fun cleanupMedia(ctx: Context) {
        try {
            val used = HashSet<String>()
            val files = dir(ctx).listFiles { f -> f.name.endsWith(".json") } ?: emptyArray()
            for (f in files) {
                val text = f.readText().replace("\\/", "/")
                val m = Regex("media/([A-Za-z0-9_.\\-]+)").findAll(text)
                for (x in m) used += x.groupValues[1]
            }
            val media = File(ctx.filesDir, "media")
            media.listFiles()?.forEach { if (it.name !in used) it.delete() }
        } catch (e: Exception) {
        }
    }
}
