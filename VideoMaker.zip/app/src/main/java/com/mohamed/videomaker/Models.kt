package com.mohamed.videomaker

import android.graphics.Bitmap
import android.net.Uri

/** تعديلات لونية: كل القيم من -1 إلى 1. */
data class Adjust(
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    val warmth: Float = 0f
) {
    val isNeutral: Boolean
        get() = brightness == 0f && contrast == 0f && saturation == 0f && warmth == 0f
}

/** فلاتر جاهزة = تعديلات لونية + رمادي/سيبيا. */
enum class ClipFilter(
    val label: String,
    val gray: Boolean = false,
    val sepia: Boolean = false,
    val adjust: Adjust = Adjust()
) {
    NONE("بدون"),
    VIVID("حيوي", adjust = Adjust(contrast = 0.15f, saturation = 0.35f)),
    WARM("دافئ", adjust = Adjust(warmth = 0.5f, saturation = 0.1f)),
    COOL("بارد", adjust = Adjust(warmth = -0.5f)),
    BRIGHT("مضيء", adjust = Adjust(brightness = 0.12f, contrast = 0.05f)),
    DRAMATIC("درامي", adjust = Adjust(contrast = 0.35f, saturation = -0.15f, brightness = -0.05f)),
    FADED("باهت", adjust = Adjust(contrast = -0.2f, saturation = -0.3f, brightness = 0.08f)),
    SEPIA("سيبيا", sepia = true),
    BW("أبيض وأسود", gray = true),
    NOIR("أسود درامي", gray = true, adjust = Adjust(contrast = 0.4f))
}

enum class ClipAnim(val label: String) {
    NONE("بدون"),
    FADE("تلاشي"),
    ZOOM("تكبير"),
    SLOW_ZOOM_IN("تقريب بطيء"),
    SLOW_ZOOM_OUT("إبعاد بطيء")
}

enum class AspectOption(val label: String, val w: Int, val h: Int) {
    WIDE("16:9", 16, 9),
    TALL("9:16", 9, 16),
    SQUARE("1:1", 1, 1),
    PORTRAIT("4:5", 4, 5),
    CLASSIC("4:3", 4, 3),
    CINEMA("21:9", 21, 9);

    val ratio: Float get() = w.toFloat() / h
}

enum class TextFont(val label: String, val family: String) {
    SANS("عادي", "sans-serif"),
    SERIF("كلاسيكي", "serif"),
    CONDENSED("ضيق", "sans-serif-condensed"),
    MONO("ثابت", "monospace"),
    CURSIVE("يدوي", "cursive"),
    CASUAL("حر", "casual")
}

enum class TextAnim(val label: String) {
    NONE("بدون"),
    FADE("تلاشي")
}

/** مقطع فيديو أو صورة على المسار الرئيسي. */
data class VisualClip(
    val id: Long,
    val uri: Uri,
    val isImage: Boolean,
    val sourceMs: Long,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = sourceMs,
    val imageMs: Long = 5000L,
    val speed: Float = 1f,
    val volume: Float = 1f,
    val muted: Boolean = false,
    val filter: ClipFilter = ClipFilter.NONE,
    val adjust: Adjust = Adjust(),
    val rotation: Int = 0,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val fill: Boolean = false,
    val anim: ClipAnim = ClipAnim.NONE,
    val thumb: Bitmap? = null,
    val srcWidth: Int = 0,
    val srcHeight: Int = 0
) {
    /** مدة المقطع في المشروع بعد القص والسرعة. */
    val outMs: Long
        get() = if (isImage) imageMs else ((trimEndMs - trimStartMs) / speed).toLong().coerceAtLeast(100L)

    val trimmedMs: Long get() = (trimEndMs - trimStartMs).coerceAtLeast(100L)
}

/** عنصر صوتي (موسيقى / تعليق صوتي / صوت مفصول من فيديو). */
data class AudioItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val sourceMs: Long,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = sourceMs,
    val startMs: Long = 0L,
    val volume: Float = 1f,
    val fadeInMs: Long = 0L,
    val fadeOutMs: Long = 0L,
    val kind: Int = KIND_MUSIC
) {
    val lengthMs: Long get() = (trimEndMs - trimStartMs).coerceAtLeast(100L)
    val endMs: Long get() = startMs + lengthMs

    companion object {
        const val KIND_MUSIC = 0
        const val KIND_VOICE = 1
        const val KIND_EXTRACTED = 2
    }
}

/** نص أو ملصق فوق الفيديو. المواضع كنسب من الإطار (0..1). */
data class TextItem(
    val id: Long,
    val text: String,
    val startMs: Long,
    val durationMs: Long = 4000L,
    val x: Float = 0.5f,
    val y: Float = 0.8f,
    val sizeFrac: Float = 0.07f,
    val color: Int = 0xFFFFFFFF.toInt(),
    val bgColor: Int = 0x99000000.toInt(),
    val bold: Boolean = true,
    val italic: Boolean = false,
    val font: TextFont = TextFont.SANS,
    val anim: TextAnim = TextAnim.FADE,
    val rotation: Float = 0f,
    val isSticker: Boolean = false
) {
    val endMs: Long get() = startMs + durationMs
}

data class Project(
    val clips: List<VisualClip> = emptyList(),
    val audios: List<AudioItem> = emptyList(),
    val texts: List<TextItem> = emptyList(),
    val aspect: AspectOption = AspectOption.WIDE
) {
    val totalMs: Long get() = clips.sumOf { it.outMs }

    /** بداية كل مقطع على التايم لاين. */
    fun startOf(clipId: Long): Long {
        var t = 0L
        for (c in clips) {
            if (c.id == clipId) return t
            t += c.outMs
        }
        return t
    }

    /** نهاية آخر صوت. */
    val audioEndMs: Long get() = audios.maxOfOrNull { it.endMs } ?: 0L
}

sealed class Selection {
    data class Clip(val id: Long) : Selection()
    data class Audio(val id: Long) : Selection()
    data class Text(val id: Long) : Selection()
}

enum class Panel {
    TRIM_IMAGE, SPEED, VOLUME, FILTER, ADJUST, ANIM, AUDIO_VOLUME, AUDIO_FADE,
    TEXT_EDIT, TEXT_STYLE, STICKERS, ASPECT, RECORD
}

enum class ExportRes(val label: String, val longSide: Int, val base: Int) {
    R480("480p", 854, 480),
    R720("720p HD", 1280, 720),
    R1080("1080p FHD", 1920, 1080)
}

enum class ExportQuality(val label: String, val bpp: Float) {
    LOW("اقتصادية", 0.07f),
    MEDIUM("متوسطة", 0.11f),
    HIGH("عالية", 0.18f)
}

data class ExportConfig(
    val res: ExportRes = ExportRes.R720,
    val fps: Int = 30,
    val quality: ExportQuality = ExportQuality.MEDIUM
) {
    /** مقاس الإطار النهائي (أرقام زوجية). */
    fun size(aspect: AspectOption): Pair<Int, Int> {
        val r = aspect.ratio
        val long = res.longSide
        var w: Int
        var h: Int
        if (r >= 1f) {
            w = long
            h = (long / r).toInt()
        } else {
            h = long
            w = (long * r).toInt()
        }
        w -= w % 2
        h -= h % 2
        return Pair(w, h)
    }

    fun bitrate(aspect: AspectOption): Int {
        val (w, h) = size(aspect)
        return (w.toLong() * h * fps * quality.bpp).toLong().coerceIn(500_000L, 40_000_000L).toInt()
    }
}

fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
}

fun formatTimeTenths(ms: Long): String {
    val t = ms.coerceAtLeast(0)
    return formatTime(t) + "." + ((t % 1000) / 100)
}
