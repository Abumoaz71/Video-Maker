package com.mohamed.videomaker

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.Environment
import android.provider.MediaStore
import androidx.core.net.toUri
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** يبني الـ Composition ويشغّل Transformer (لازم يتنادى كله من الـ Main thread). */
class Exporter(private val context: Context) {

    interface Callback {
        fun onDone(file: File)
        fun onError(message: String)
        fun onStage(message: String) {}
    }

    private var transformer: Transformer? = null

    /** ملف صوت صامت (ستيريو 44.1k) بالمدة المطلوبة، لإزاحة بداية الصوت. */
    private fun silenceWav(durationMs: Long): Uri {
        val capped = durationMs.coerceIn(100L, 30L * 60_000L)
        val file = File(context.cacheDir, "silence_$capped.wav")
        if (!file.exists() || file.length() < 44) {
            val sampleRate = 44100
            val frames = capped * sampleRate / 1000L
            val dataBytes = frames * 4L
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray())
            header.putInt((36L + dataBytes).toInt())
            header.put("WAVE".toByteArray())
            header.put("fmt ".toByteArray())
            header.putInt(16)
            header.putShort(1)
            header.putShort(2)
            header.putInt(sampleRate)
            header.putInt(sampleRate * 4)
            header.putShort(4)
            header.putShort(16)
            header.put("data".toByteArray())
            header.putInt(dataBytes.toInt())
            FileOutputStream(file).use { out ->
                out.write(header.array())
                val chunk = ByteArray(65536)
                var left = dataBytes
                while (left > 0) {
                    val n = minOf(left, chunk.size.toLong()).toInt()
                    out.write(chunk, 0, n)
                    left -= n
                }
            }
        }
        return file.toUri()
    }

    /** صمت بأي مدة كقائمة عناصر (كل عنصر لا يزيد عن دقيقتين عشان حجم الملف المؤقت). */
    private fun silenceItems(durationMs: Long): List<EditedMediaItem> {
        val out = ArrayList<EditedMediaItem>()
        val chunk = 120_000L
        var left = durationMs
        while (left > 0L) {
            val n = minOf(left, chunk)
            if (n >= 100L) {
                out.add(EditedMediaItem.Builder(MediaItem.fromUri(silenceWav(n))).build())
            }
            left -= n
        }
        return out
    }

    private fun forceAudioTrack(builder: Any) {
        try {
            builder.javaClass
                .getMethod("experimentalSetForceAudioTrack", java.lang.Boolean.TYPE)
                .invoke(builder, true)
        } catch (e: Throwable) {
            // الدالة مش موجودة في الـ builder ده، عادي
        }
    }

    /** مسارات الصوت المضافة (موسيقى/تسجيل) كل واحد في Sequence مستقل. */
    private fun addedAudioSequences(p: Project): List<EditedMediaItemSequence> {
        val total = p.totalMs
        val out = ArrayList<EditedMediaItemSequence>()
        for (a in p.audios) {
            if (a.startMs >= total) continue
            val usable = minOf(a.lengthMs, total - a.startMs)
            if (usable < 100L) continue
            val trimEnd = a.trimStartMs + usable

            val audioItem = EditedMediaItem.Builder(
                MediaItem.Builder().setUri(a.uri).setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(a.trimStartMs)
                        .setEndPositionMs(trimEnd)
                        .build()
                ).build()
            )
                .setRemoveVideo(true)
                .setEffects(
                    Effects(
                        listOf<AudioProcessor>(
                            FadeVolumeProcessor(a.volume, a.fadeInMs, a.fadeOutMs, usable)
                        ),
                        emptyList()
                    )
                )
                .build()

            val seqItems = mutableListOf<EditedMediaItem>()
            if (a.startMs > 0L) seqItems.addAll(silenceItems(a.startMs))
            seqItems.add(audioItem)
            out.add(EditedMediaItemSequence.Builder(seqItems).build())
        }
        return out
    }

    /** تركيبة صوت فقط (للطريقة البديلة): صوت مقاطع الفيديو + الصوتيات المضافة. */
    private fun buildAudioComposition(p: Project): Composition? {
        val sequences = ArrayList<EditedMediaItemSequence>()
        if (p.clips.any { !it.isImage && !it.muted && it.volume > 0f }) {
            val items = ArrayList<EditedMediaItem>()
            for (clip in p.clips) {
                if (clip.isImage || clip.muted || clip.volume <= 0f) {
                    items.addAll(silenceItems(clip.outMs))
                    continue
                }
                val procs = mutableListOf<AudioProcessor>()
                if (clip.speed != 1f && speedVideoEffect(clip.speed) != null) procs.add(speedAudioProcessor(clip.speed))
                if (clip.volume != 1f) procs.add(FadeVolumeProcessor(clip.volume, 0L, 0L, clip.outMs))
                items.add(
                    EditedMediaItem.Builder(
                        MediaItem.Builder().setUri(clip.uri).setClippingConfiguration(
                            MediaItem.ClippingConfiguration.Builder()
                                .setStartPositionMs(clip.trimStartMs)
                                .setEndPositionMs(clip.trimEndMs)
                                .build()
                        ).build()
                    )
                        .setRemoveVideo(true)
                        .setEffects(Effects(procs, emptyList()))
                        .build()
                )
            }
            if (items.isNotEmpty()) sequences.add(EditedMediaItemSequence.Builder(items).build())
        }
        sequences.addAll(addedAudioSequences(p))
        if (sequences.isEmpty()) return null
        return Composition.Builder(sequences).build()
    }

    private fun expectsAudio(p: Project): Boolean {
        val total = p.totalMs
        return p.audios.any { it.startMs < total && minOf(it.lengthMs, total - it.startMs) >= 100L }
    }

    private fun hasAudioTrack(f: File): Boolean {
        return try {
            val ex = MediaExtractor()
            try {
                ex.setDataSource(f.absolutePath)
                (0 until ex.trackCount).any {
                    ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
                }
            } finally {
                ex.release()
            }
        } catch (e: Exception) {
            true // لو معرفناش نفحص، نفترض إنه سليم
        }
    }

    fun buildComposition(p: Project, cfg: ExportConfig, includeAudio: Boolean = true): Composition {
        val (frameW, frameH) = cfg.size(p.aspect)
        val total = p.totalMs

        // ---------- المسار الرئيسي ----------
        val items = p.clips.map { clip ->
            val mediaItem = MediaItem.Builder().setUri(clip.uri).apply {
                if (clip.isImage) {
                    setImageDurationMs(clip.imageMs)
                } else {
                    setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(clip.trimStartMs)
                            .setEndPositionMs(clip.trimEndMs)
                            .build()
                    )
                }
            }.build()

            val videoEffects = mutableListOf<Effect>()
            val audioProcs = mutableListOf<AudioProcessor>()
            val removeAudio = !includeAudio || (!clip.isImage && (clip.muted || clip.volume <= 0f))

            var speedOk = false
            if (!clip.isImage && clip.speed != 1f) {
                val se = speedVideoEffect(clip.speed)
                if (se != null) {
                    videoEffects.add(se)
                    speedOk = true
                }
            }
            if (speedOk && !removeAudio) audioProcs.add(speedAudioProcessor(clip.speed))
            if (!clip.isImage && !removeAudio && clip.volume != 1f) {
                audioProcs.add(FadeVolumeProcessor(clip.volume, 0L, 0L, clip.outMs))
            }
            videoEffects.addAll(clipVideoEffects(clip, frameW, frameH))

            val builder = EditedMediaItem.Builder(mediaItem)
                .setEffects(Effects(audioProcs, videoEffects))
                .setRemoveAudio(removeAudio)
            if (clip.isImage) {
                val moving = clip.anim == ClipAnim.SLOW_ZOOM_IN || clip.anim == ClipAnim.SLOW_ZOOM_OUT
                val fps = if (clip.imageMs > 20_000L && !moving) 10 else cfg.fps
                builder.setFrameRate(fps)
            }
            builder.build()
        }

        val mainBuilder = EditedMediaItemSequence.Builder(items)
        if (includeAudio) forceAudioTrack(mainBuilder)
        val sequences = mutableListOf(mainBuilder.build())

        // ---------- مسارات الصوت ----------
        if (includeAudio) sequences.addAll(addedAudioSequences(p))

        // ---------- النصوص ----------
        val compBuilder = Composition.Builder(sequences)
        if (includeAudio) forceAudioTrack(compBuilder)
        val visibleTexts = p.texts.filter { it.startMs < total }
        val textEffect = textOverlaysEffect(visibleTexts, frameW, frameH)
        if (textEffect != null) {
            compBuilder.setEffects(Effects(emptyList(), listOf(textEffect)))
        }
        return compBuilder.build()
    }

    private val main = Handler(Looper.getMainLooper())

    private fun newTransformer(
        withVideo: Boolean,
        project: Project,
        cfg: ExportConfig,
        onOk: () -> Unit,
        onFail: (String) -> Unit
    ): Transformer {
        val b = Transformer.Builder(context)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    onOk()
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    onFail(exportException.message ?: "حصل خطأ أثناء التصدير")
                }
            })
        if (withVideo) {
            val encoderSettings = VideoEncoderSettings.Builder()
                .setBitrate(cfg.bitrate(project.aspect))
                .build()
            val encoderFactory = DefaultEncoderFactory.Builder(context)
                .setRequestedVideoEncoderSettings(encoderSettings)
                .build()
            b.setVideoMimeType(MimeTypes.VIDEO_H264).setEncoderFactory(encoderFactory)
        }
        return b.build()
    }

    /** 0 = فيديو، 1 = صوت، 2 = دمج (لحساب نسبة التقدم). */
    @Volatile
    private var phase = 0
    @Volatile
    private var twoPass = false

    fun start(project: Project, cfg: ExportConfig, outFile: File, callback: Callback) {
        if (outFile.exists()) outFile.delete()
        phase = 0
        if (expectsAudio(project)) {
            // الأضمن: فيديو بدون صوت + صوت منفصل ثم دمجهم (بدون الاعتماد على خلط الصوت جوه Composition)
            twoPass = true
            runTwoPass(project, cfg, outFile, callback)
            return
        }
        twoPass = false
        val composition = buildComposition(project, cfg)
        val t = newTransformer(
            withVideo = true,
            project = project,
            cfg = cfg,
            onOk = { callback.onDone(outFile) },
            onFail = { callback.onError(it) }
        )
        transformer = t
        t.start(composition, outFile.absolutePath)
    }

    private fun runTwoPass(project: Project, cfg: ExportConfig, outFile: File, callback: Callback) {
        val videoOnly = File(context.cacheDir, "tp_video.mp4")
        val audioOnly = File(context.cacheDir, "tp_audio.m4a")
        videoOnly.delete()
        audioOnly.delete()
        val audioComp = buildAudioComposition(project)
        if (audioComp == null) {
            callback.onError("لا يوجد صوت صالح للتصدير")
            return
        }

        val tAudio = newTransformer(
            withVideo = false,
            project = project,
            cfg = cfg,
            onOk = {
                phase = 2
                Thread {
                    try {
                        mux(videoOnly, audioOnly, outFile)
                        videoOnly.delete()
                        audioOnly.delete()
                        main.post { callback.onDone(outFile) }
                    } catch (e: Exception) {
                        main.post { callback.onError("فشل دمج الصوت: " + (e.message ?: "")) }
                    }
                }.start()
            },
            onFail = { callback.onError(it) }
        )

        val tVideo = newTransformer(
            withVideo = true,
            project = project,
            cfg = cfg,
            onOk = {
                phase = 1
                transformer = tAudio
                callback.onStage("جاري تجهيز الصوت...")
                tAudio.start(audioComp, audioOnly.absolutePath)
            },
            onFail = { callback.onError(it) }
        )
        transformer = tVideo
        tVideo.start(buildComposition(project, cfg, includeAudio = false), videoOnly.absolutePath)
    }

    private fun firstTrack(ex: MediaExtractor, prefix: String): Int {
        for (i in 0 until ex.trackCount) {
            if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith(prefix) == true) return i
        }
        error("no $prefix track")
    }

    /** يدمج مسار الفيديو من ملف ومسار الصوت من ملف تاني في MP4 واحد (بدون إعادة ترميز). */
    private fun mux(video: File, audio: File, out: File) {
        if (out.exists()) out.delete()
        val vEx = MediaExtractor()
        val aEx = MediaExtractor()
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var started = false
        try {
            vEx.setDataSource(video.absolutePath)
            aEx.setDataSource(audio.absolutePath)
            val vi = firstTrack(vEx, "video/")
            val ai = firstTrack(aEx, "audio/")
            vEx.selectTrack(vi)
            aEx.selectTrack(ai)
            val vFormat = vEx.getTrackFormat(vi)
            val vOut = muxer.addTrack(vFormat)
            val aOut = muxer.addTrack(aEx.getTrackFormat(ai))
            val limitUs = if (vFormat.containsKey(MediaFormat.KEY_DURATION)) vFormat.getLong(MediaFormat.KEY_DURATION) else Long.MAX_VALUE
            muxer.start()
            started = true

            val buf = ByteBuffer.allocate(8 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var vDone = false
            var aDone = false
            while (!vDone || !aDone) {
                val takeVideo = when {
                    vDone -> false
                    aDone -> true
                    else -> vEx.sampleTime <= aEx.sampleTime
                }
                val ex = if (takeVideo) vEx else aEx
                val track = if (takeVideo) vOut else aOut
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                val t = ex.sampleTime
                if (n < 0 || (!takeVideo && t > limitUs)) {
                    if (takeVideo) vDone = true else aDone = true
                    continue
                }
                info.set(
                    0, n, t,
                    if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                )
                muxer.writeSampleData(track, buf, info)
                ex.advance()
            }
        } finally {
            try { if (started) muxer.stop() } catch (e: Exception) {}
            try { muxer.release() } catch (e: Exception) {}
            vEx.release()
            aEx.release()
        }
    }

    /** نسبة التقدم من 0 إلى 1 (أو -1 لو لسه مش متاحة). */
    fun progress(): Float {
        val t = transformer ?: return -1f
        val holder = ProgressHolder()
        val state = t.getProgress(holder)
        if (state != Transformer.PROGRESS_STATE_AVAILABLE) return if (phase == 2) 0.99f else -1f
        val p = holder.progress / 100f
        if (!twoPass) return p
        return when (phase) {
            0 -> p * 0.85f
            1 -> 0.85f + p * 0.13f
            else -> 0.99f
        }
    }

    fun cancel() {
        transformer?.cancel()
        transformer = null
    }

    companion object {
        /** ينسخ الفيديو النهائي لمعرض الصور (Movies/VideoMaker). */
        fun saveToGallery(context: Context, file: File): Uri? {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(
                    MediaStore.Video.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_MOVIES + "/VideoMaker"
                )
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: return null
            resolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        }
    }
}
