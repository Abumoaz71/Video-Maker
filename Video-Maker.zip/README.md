# صانع الفيديو
1. ارفع الملف VideoMaker.zip فقط (بدون فك) على الريبو.
2. الـ workflow موجود في .github/workflows/build.yml (مرة واحدة).
3. Actions -> Build APK -> نزّل VideoMaker-debug-apk.
