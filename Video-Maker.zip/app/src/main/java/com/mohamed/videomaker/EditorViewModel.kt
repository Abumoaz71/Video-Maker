package com.mohamed.videomaker

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.net.toUri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    var project by mutableStateOf(Project())
        private set
    var selection by mutableStateOf<Selection?>(null)
    var panel by mutableStateOf<Panel?>(null)
    var message by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)

    val engine = PreviewEngine(app, viewModelScope)

    private val idGen = AtomicLong(1)
    private val undoStack = ArrayList<Project>()
    private val redoStack = ArrayList<Project>()
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    // ---------- التصدير ----------
    var exportConfig by mutableStateOf(ExportConfig())
    var exporting by mutableStateOf(false)
    var exportProgress by mutableFloatStateOf(0f)
    var resultUri by mutableStateOf<Uri?>(null)
    var exportError by mutableStateOf<String?>(null)
    private val exporter = Exporter(app)
    private var progressJob: Job? = null

    // ---------- التسجيل ----------
    var recording by mutableStateOf(false)
        private set
    private var recorder: MediaRecorder? = null
    private var recFile: File? = null
    private var recStartPos = 0L

    // =====================================================================
    // الحالة والتراجع
    // =====================================================================

    private fun apply(p: Project) {
        project = p
        engine.setProject(p)
    }

    /** يحفظ الحالة الحالية للتراجع (يتنادى قبل أي تعديل). */
    fun checkpoint() {
        undoStack.add(project)
        if (undoStack.size > 60) undoStack.removeAt(0)
        redoStack.clear()
        canUndo = true
        canRedo = false
    }

    private fun edit(f: (Project) -> Project) {
        checkpoint()
        apply(f(project))
    }

    /** تعديل لحظي (سلايدر) بدون حفظ نقطة تراجع جديدة. */
    fun live(f: (Project) -> Project) {
        apply(f(project))
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(project)
        apply(undoStack.removeAt(undoStack.lastIndex))
        canUndo = undoStack.isNotEmpty()
        canRedo = true
        fixSelection()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(project)
        apply(redoStack.removeAt(redoStack.lastIndex))
        canUndo = true
        canRedo = redoStack.isNotEmpty()
        fixSelection()
    }

    private fun fixSelection() {
        val s = selection
        val ok = when (s) {
            is Selection.Clip -> project.clips.any { it.id == s.id }
            is Selection.Audio -> project.audios.any { it.id == s.id }
            is Selection.Text -> project.texts.any { it.id == s.id }
            null -> true
        }
        if (!ok) {
            selection = null
            panel = null
        }
    }

    /** يمسح المشروع بالكامل (الخروج للشاشة الرئيسية). */
    fun resetProject() {
        if (recording) stopRecording()
        undoStack.clear()
        redoStack.clear()
        canUndo = false
        canRedo = false
        selection = null
        panel = null
        engine.pause()
        engine.seekTo(0L)
        apply(Project())
    }

    fun clearMessage() {
        message = null
    }

    // =====================================================================
    // استيراد الوسائط
    // =====================================================================

    fun addMedia(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            busy = true
            for (uri in uris) {
                val clip = withContext(Dispatchers.IO) { loadClip(uri) }
                if (clip == null) {
                    message = "مقدرتش أقرأ واحد من الملفات"
                    continue
                }
                var c: VisualClip = clip
                if (c.isImage && project.audios.isNotEmpty() && project.clips.isEmpty()) {
                    val want = project.audioEndMs - project.totalMs
                    if (want > 3000L) c = c.copy(imageMs = want)
                }
                edit { it.copy(clips = it.clips + c) }
                selection = Selection.Clip(c.id)
            }
            busy = false
        }
    }

    private fun loadClip(uri: Uri): VisualClip? {
        val ctx = getApplication<Application>()
        val mime = ctx.contentResolver.getType(uri) ?: ""
        if (mime.startsWith("image/")) {
            return try {
                val resolver = ctx.contentResolver
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: return null
                VisualClip(
                    id = idGen.getAndIncrement(),
                    uri = uri,
                    isImage = true,
                    sourceMs = 0L,
                    imageMs = 5000L,
                    thumb = bmp,
                    srcWidth = bounds.outWidth,
                    srcHeight = bounds.outHeight
                )
            } catch (e: Exception) {
                null
            }
        }
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (dur <= 0L) return null
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) {
                val tmp = w
                w = h
                h = tmp
            }
            val frame = r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            VisualClip(
                id = idGen.getAndIncrement(),
                uri = uri,
                isImage = false,
                sourceMs = dur,
                thumb = frame?.let { scaleDown(it, 320) },
                srcWidth = w,
                srcHeight = h
            )
        } catch (e: Exception) {
            null
        } finally {
            r.release()
        }
    }

    private fun scaleDown(src: Bitmap, targetHeight: Int): Bitmap {
        if (src.height <= targetHeight) return src
        val ratio = targetHeight.toFloat() / src.height
        return Bitmap.createScaledBitmap(src, (src.width * ratio).toInt().coerceAtLeast(1), targetHeight, true)
    }

    private fun queryName(uri: Uri): String {
        return try {
            getApplication<Application>().contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && idx >= 0) c.getString(idx) else null
            } ?: "ملف صوتي"
        } catch (e: Exception) {
            "ملف صوتي"
        }
    }

    private fun audioDuration(uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(getApplication<Application>(), uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            r.release()
        }
    }

    fun addAudio(uri: Uri, kind: Int = AudioItem.KIND_MUSIC, name: String? = null, startMs: Long? = null) {
        viewModelScope.launch {
            val dur = withContext(Dispatchers.IO) { audioDuration(uri) }
            if (dur <= 0L) {
                message = "الملف الصوتي مش مقروء"
                return@launch
            }
            val title = name ?: withContext(Dispatchers.IO) { queryName(uri) }
            val a = AudioItem(
                id = idGen.getAndIncrement(),
                uri = uri,
                name = title,
                sourceMs = dur,
                startMs = startMs ?: engine.positionMs.coerceAtMost(project.totalMs),
                kind = kind
            )
            checkpoint()
            var p = project.copy(audios = project.audios + a)
            // لو المشروع كله صور والصوت أطول: مد آخر صورة لتطابق الصوت
            val allImages = p.clips.isNotEmpty() && p.clips.all { it.isImage }
            if (allImages && p.audioEndMs > p.totalMs) {
                val last = p.clips.last()
                val extra = p.audioEndMs - p.totalMs
                p = p.copy(clips = p.clips.dropLast(1) + last.copy(imageMs = last.imageMs + extra))
                message = "تم مد مدة الصورة لتطابق طول الصوت (${formatTime(p.audioEndMs)})"
            }
            apply(p)
            selection = Selection.Audio(a.id)
        }
    }

    // =====================================================================
    // المقاطع
    // =====================================================================

    fun clipById(id: Long): VisualClip? = project.clips.firstOrNull { it.id == id }
    fun audioById(id: Long): AudioItem? = project.audios.firstOrNull { it.id == id }
    fun textById(id: Long): TextItem? = project.texts.firstOrNull { it.id == id }

    fun selectedClip(): VisualClip? = (selection as? Selection.Clip)?.let { clipById(it.id) }
    fun selectedAudio(): AudioItem? = (selection as? Selection.Audio)?.let { audioById(it.id) }
    fun selectedText(): TextItem? = (selection as? Selection.Text)?.let { textById(it.id) }

    fun updateClip(id: Long, history: Boolean = true, f: (VisualClip) -> VisualClip) {
        val g = { p: Project -> p.copy(clips = p.clips.map { if (it.id == id) f(it) else it }) }
        if (history) edit(g) else live(g)
    }

    fun updateAudio(id: Long, history: Boolean = true, f: (AudioItem) -> AudioItem) {
        val g = { p: Project -> p.copy(audios = p.audios.map { if (it.id == id) f(it) else it }) }
        if (history) edit(g) else live(g)
    }

    fun updateText(id: Long, history: Boolean = true, f: (TextItem) -> TextItem) {
        val g = { p: Project -> p.copy(texts = p.texts.map { if (it.id == id) f(it) else it }) }
        if (history) edit(g) else live(g)
    }

    fun deleteSelected() {
        when (val s = selection) {
            is Selection.Clip -> edit { it.copy(clips = it.clips.filter { c -> c.id != s.id }) }
            is Selection.Audio -> edit { it.copy(audios = it.audios.filter { a -> a.id != s.id }) }
            is Selection.Text -> edit { it.copy(texts = it.texts.filter { t -> t.id != s.id }) }
            null -> return
        }
        selection = null
        panel = null
    }

    fun duplicateSelected() {
        when (val s = selection) {
            is Selection.Clip -> {
                val c = clipById(s.id) ?: return
                val copy = c.copy(id = idGen.getAndIncrement())
                edit {
                    val i = it.clips.indexOfFirst { x -> x.id == s.id }
                    val list = it.clips.toMutableList()
                    list.add(i + 1, copy)
                    it.copy(clips = list)
                }
                selection = Selection.Clip(copy.id)
            }
            is Selection.Audio -> {
                val a = audioById(s.id) ?: return
                val copy = a.copy(id = idGen.getAndIncrement(), startMs = a.endMs)
                edit { it.copy(audios = it.audios + copy) }
                selection = Selection.Audio(copy.id)
            }
            is Selection.Text -> {
                val t = textById(s.id) ?: return
                val copy = t.copy(id = idGen.getAndIncrement(), y = (t.y - 0.1f).coerceIn(0.1f, 0.9f))
                edit { it.copy(texts = it.texts + copy) }
                selection = Selection.Text(copy.id)
            }
            null -> return
        }
    }

    fun moveSelectedClip(delta: Int) {
        val s = selection as? Selection.Clip ?: return
        val i = project.clips.indexOfFirst { it.id == s.id }
        val j = i + delta
        if (i < 0 || j !in project.clips.indices) return
        edit {
            val list = it.clips.toMutableList()
            val tmp = list[i]
            list[i] = list[j]
            list[j] = tmp
            it.copy(clips = list)
        }
    }

    /** تقسيم المحدد (أو المقطع تحت المؤشر) عند موضع المؤشر. */
    fun splitAtPlayhead() {
        val t = engine.positionMs
        val s = selection
        if (s is Selection.Audio) {
            val a = audioById(s.id) ?: return
            val local = t - a.startMs
            if (local < 300L || local > a.lengthMs - 300L) {
                message = "حرّك المؤشر داخل المقطع الصوتي"
                return
            }
            val left = a.copy(trimEndMs = a.trimStartMs + local, fadeOutMs = 0L)
            val right = a.copy(
                id = idGen.getAndIncrement(),
                trimStartMs = a.trimStartMs + local,
                startMs = t,
                fadeInMs = 0L
            )
            edit { p -> p.copy(audios = p.audios.flatMap { if (it.id == a.id) listOf(left, right) else listOf(it) }) }
            selection = Selection.Audio(right.id)
            return
        }
        val target: VisualClip
        val start: Long
        if (s is Selection.Clip) {
            target = clipById(s.id) ?: return
            start = project.startOf(target.id)
        } else {
            val ac = engine.activeClip(t) ?: return
            target = ac.first
            start = ac.second
        }
        val local = t - start
        if (local < 300L || local > target.outMs - 300L) {
            message = "حرّك المؤشر داخل المقطع المراد تقسيمه"
            return
        }
        val left: VisualClip
        val right: VisualClip
        if (target.isImage) {
            left = target.copy(imageMs = local)
            right = target.copy(id = idGen.getAndIncrement(), imageMs = target.imageMs - local)
        } else {
            val srcLocal = (local * target.speed).toLong()
            left = target.copy(trimEndMs = target.trimStartMs + srcLocal)
            right = target.copy(id = idGen.getAndIncrement(), trimStartMs = target.trimStartMs + srcLocal)
        }
        edit { p -> p.copy(clips = p.clips.flatMap { if (it.id == target.id) listOf(left, right) else listOf(it) }) }
        selection = Selection.Clip(right.id)
    }

    /** سحب حافة المقطع في التايم لاين. deltaOutMs بالزمن الظاهر على التايم لاين. */
    fun resizeClipEdge(id: Long, startEdge: Boolean, deltaOutMs: Long) {
        val c = clipById(id) ?: return
        if (c.isImage) {
            val newMs = if (startEdge) c.imageMs - deltaOutMs else c.imageMs + deltaOutMs
            updateClip(id, false) { it.copy(imageMs = newMs.coerceIn(300L, 6L * 3600_000L)) }
        } else {
            val d = (deltaOutMs * c.speed).toLong()
            if (startEdge) {
                val ns = (c.trimStartMs + d).coerceIn(0L, c.trimEndMs - 300L)
                updateClip(id, false) { it.copy(trimStartMs = ns) }
            } else {
                val ne = (c.trimEndMs + d).coerceIn(c.trimStartMs + 300L, c.sourceMs)
                updateClip(id, false) { it.copy(trimEndMs = ne) }
            }
        }
    }

    fun resizeAudioEdge(id: Long, startEdge: Boolean, deltaMs: Long) {
        val a = audioById(id) ?: return
        if (startEdge) {
            val ns = (a.trimStartMs + deltaMs).coerceIn(0L, a.trimEndMs - 300L)
            val applied = ns - a.trimStartMs
            updateAudio(id, false) { it.copy(trimStartMs = ns, startMs = (it.startMs + applied).coerceAtLeast(0L)) }
        } else {
            val ne = (a.trimEndMs + deltaMs).coerceIn(a.trimStartMs + 300L, a.sourceMs)
            updateAudio(id, false) { it.copy(trimEndMs = ne) }
        }
    }

    fun moveAudio(id: Long, deltaMs: Long) {
        updateAudio(id, false) { it.copy(startMs = (it.startMs + deltaMs).coerceAtLeast(0L)) }
    }

    fun resizeTextEdge(id: Long, startEdge: Boolean, deltaMs: Long) {
        val t = textById(id) ?: return
        if (startEdge) {
            val ns = (t.startMs + deltaMs).coerceIn(0L, t.endMs - 300L)
            updateText(id, false) { it.copy(startMs = ns, durationMs = it.endMs - ns) }
        } else {
            updateText(id, false) { it.copy(durationMs = (it.durationMs + deltaMs).coerceAtLeast(300L)) }
        }
    }

    fun moveText(id: Long, deltaMs: Long) {
        updateText(id, false) { it.copy(startMs = (it.startMs + deltaMs).coerceAtLeast(0L)) }
    }

    fun setImageDuration(id: Long, ms: Long) {
        updateClip(id) { it.copy(imageMs = ms.coerceIn(300L, 6L * 3600_000L)) }
    }

    /** مدة الصورة المحددة بحيث ينتهي المشروع مع نهاية الصوت. */
    fun matchAudioLength(id: Long) {
        val c = clipById(id) ?: return
        if (!c.isImage) return
        val extra = project.audioEndMs - project.totalMs
        if (project.audios.isEmpty()) {
            message = "أضف صوتًا أولًا"
            return
        }
        if (extra == 0L) {
            message = "المدة مطابقة للصوت بالفعل"
            return
        }
        setImageDuration(id, c.imageMs + extra)
    }

    fun applyFilterToAll(filter: ClipFilter) {
        edit { p -> p.copy(clips = p.clips.map { it.copy(filter = filter) }) }
    }

    fun applyAnimToAll(anim: ClipAnim) {
        edit { p -> p.copy(clips = p.clips.map { it.copy(anim = anim) }) }
    }

    fun setAspect(a: AspectOption) {
        edit { it.copy(aspect = a) }
    }

    /** فصل الصوت من الفيديو: يتحول لعنصر صوتي مستقل ويُكتم المقطع. */
    fun extractAudio() {
        val c = selectedClip() ?: return
        if (c.isImage) {
            message = "الصورة مفيهاش صوت"
            return
        }
        val a = AudioItem(
            id = idGen.getAndIncrement(),
            uri = c.uri,
            name = "صوت من فيديو",
            sourceMs = c.sourceMs,
            trimStartMs = c.trimStartMs,
            trimEndMs = c.trimEndMs,
            startMs = project.startOf(c.id),
            volume = c.volume,
            kind = AudioItem.KIND_EXTRACTED
        )
        edit { p ->
            p.copy(
                audios = p.audios + a,
                clips = p.clips.map { if (it.id == c.id) it.copy(muted = true) else it }
            )
        }
        selection = Selection.Audio(a.id)
        message = "تم فصل الصوت في مسار مستقل"
    }

    // =====================================================================
    // النصوص والملصقات
    // =====================================================================

    fun addText(text: String = "اكتب هنا") {
        val total = project.totalMs
        val start = engine.positionMs.coerceAtMost((total - 500L).coerceAtLeast(0L))
        val t = TextItem(
            id = idGen.getAndIncrement(),
            text = text,
            startMs = start,
            durationMs = minOf(4000L, (total - start).coerceAtLeast(1500L))
        )
        edit { it.copy(texts = it.texts + t) }
        selection = Selection.Text(t.id)
        panel = Panel.TEXT_EDIT
    }

    fun addSticker(emoji: String) {
        val total = project.totalMs
        val start = engine.positionMs.coerceAtMost((total - 500L).coerceAtLeast(0L))
        val t = TextItem(
            id = idGen.getAndIncrement(),
            text = emoji,
            startMs = start,
            durationMs = minOf(4000L, (total - start).coerceAtLeast(1500L)),
            y = 0.5f,
            sizeFrac = 0.18f,
            bgColor = 0,
            isSticker = true
        )
        edit { it.copy(texts = it.texts + t) }
        selection = Selection.Text(t.id)
    }

    // =====================================================================
    // تسجيل الصوت
    // =====================================================================

    fun startRecording(): Boolean {
        if (recording) return false
        return try {
            val app = getApplication<Application>()
            val file = File(app.cacheDir, "voice_${System.currentTimeMillis()}.m4a")
            val rec = if (Build.VERSION.SDK_INT >= 31) {
                MediaRecorder(app)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioEncodingBitRate(128_000)
            rec.setAudioSamplingRate(44_100)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            rec.start()
            recorder = rec
            recFile = file
            recStartPos = engine.positionMs
            recording = true
            engine.play()
            true
        } catch (e: Exception) {
            message = "تعذر بدء التسجيل"
            recorder?.release()
            recorder = null
            false
        }
    }

    fun stopRecording() {
        if (!recording) return
        recording = false
        engine.pause()
        val rec = recorder
        val file = recFile
        recorder = null
        recFile = null
        var ok = true
        try {
            rec?.stop()
        } catch (e: Exception) {
            ok = false
        }
        rec?.release()
        if (ok && file != null && file.exists()) {
            addAudio(file.toUri(), AudioItem.KIND_VOICE, "تسجيل صوتي", recStartPos)
        } else {
            message = "التسجيل قصير جدًا"
        }
    }

    // =====================================================================
    // التصدير
    // =====================================================================

    fun startExport() {
        if (project.clips.isEmpty() || exporting) return
        engine.pause()
        exporting = true
        exportProgress = 0f
        resultUri = null
        exportError = null

        val app = getApplication<Application>()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val out = File(app.cacheDir, "VideoMaker_$stamp.mp4")

        try {
            exporter.start(project, exportConfig, out, object : Exporter.Callback {
                override fun onDone(file: File) {
                    viewModelScope.launch {
                        val uri = withContext(Dispatchers.IO) {
                            try {
                                Exporter.saveToGallery(app, file)
                            } catch (e: Exception) {
                                null
                            }
                        }
                        progressJob?.cancel()
                        exporting = false
                        exportProgress = 1f
                        if (uri != null) {
                            resultUri = uri
                        } else {
                            exportError = "اتعمل الفيديو بس معرفتش أحفظه في المعرض"
                        }
                    }
                }

                override fun onError(message: String) {
                    progressJob?.cancel()
                    exporting = false
                    exportError = message
                }
            })
        } catch (e: Exception) {
            exporting = false
            exportError = "فشل بدء التصدير: ${e.message}"
            return
        }

        progressJob = viewModelScope.launch {
            while (exporting) {
                val p = exporter.progress()
                if (p >= 0f) exportProgress = p
                delay(300)
            }
        }
    }

    fun cancelExport() {
        exporter.cancel()
        progressJob?.cancel()
        exporting = false
        exportError = null
    }

    fun dismissResult() {
        resultUri = null
        exportError = null
    }

    override fun onCleared() {
        exporter.cancel()
        engine.release()
        recorder?.release()
        super.onCleared()
    }
}
