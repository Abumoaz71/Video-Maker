package com.mohamed.videomaker

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object VMColors {
    val Bg = Color(0xFF0E0F14)
    val Surface = Color(0xFF181A22)
    val Surface2 = Color(0xFF232632)
    val Surface3 = Color(0xFF2E3242)
    val Accent = Color(0xFF19D3C5)
    val AccentDim = Color(0xFF0E7F78)
    val Text = Color(0xFFF2F4F8)
    val TextDim = Color(0xFF9AA0B4)
    val Danger = Color(0xFFFF5470)
    val VideoTrack = Color(0xFF3A4A6B)
    val AudioTrack = Color(0xFF1F6F5C)
    val VoiceTrack = Color(0xFF7A4A8C)
    val TextTrack = Color(0xFFB8762B)
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = VMColors.Accent,
            onPrimary = Color.Black,
            secondary = VMColors.Accent,
            background = VMColors.Bg,
            onBackground = VMColors.Text,
            surface = VMColors.Surface,
            onSurface = VMColors.Text,
            surfaceVariant = VMColors.Surface2,
            onSurfaceVariant = VMColors.TextDim,
            error = VMColors.Danger
        ),
        content = content
    )
}
