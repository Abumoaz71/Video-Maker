package com.mohamed.videomaker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val vm: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Root(vm)
                }
            }
        }
    }

    override fun onStop() {
        vm.engine.pause()
        super.onStop()
    }
}

@Composable
private fun Root(vm: EditorViewModel) {
    var started by rememberSaveable { mutableStateOf(false) }
    val hasContent = vm.project.clips.isNotEmpty() || vm.project.audios.isNotEmpty() || vm.project.texts.isNotEmpty()
    Box(Modifier.fillMaxSize().background(VMColors.Bg)) {
        if (!started && !hasContent) {
            HomeScreen(vm, onStart = { started = true })
        } else {
            EditorScreen(vm, onExit = { started = false })
        }
    }
}

// ------------------------------------------------------------------ الرئيسية

@Composable
private fun HomeScreen(vm: EditorViewModel, onStart: () -> Unit) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isNotEmpty()) {
            onStart()
            vm.addMedia(uris)
        }
    }
    Column(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(96.dp).clip(CircleShape).background(VMColors.Accent),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(56.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text("صانع الفيديو", color = VMColors.Text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(
            "مونتاج كامل مجاني بدون علامة مائية ولا اشتراك",
            color = VMColors.TextDim,
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(VMColors.Accent)
                .clickable {
                    pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                }
                .padding(vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("＋ مشروع جديد", color = Color.Black, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(VMColors.Surface2)
                .clickable { onStart() }
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("ابدأ بمشروع فاضي", color = VMColors.Text, fontSize = 15.sp)
        }
        Spacer(Modifier.height(28.dp))
        Text(
            "صور وفيديوهات بأي مدة · صوت وموسيقى وتسجيل · نصوص وملصقات · فلاتر وسرعة وحركة · تصدير حتى 1080p",
            color = VMColors.TextDim,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
    }
}

// ------------------------------------------------------------------ المحرر

@Composable
private fun EditorScreen(vm: EditorViewModel, onExit: () -> Unit) {
    val context = LocalContext.current
    var dpPerSec by rememberSaveable { mutableStateOf(24f) }
    var showExport by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isNotEmpty()) vm.addMedia(uris)
    }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        for (u in uris) vm.addAudio(u)
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startRecording() else vm.message = "لازم تسمح بالميكروفون عشان التسجيل"
    }

    val requestRecord = {
        val ok = context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (ok) vm.startRecording() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    val addMedia = {
        pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
    }
    val addAudio = { pickAudio.launch(arrayOf("audio/*", "video/mp4")) }

    BackHandler {
        when {
            vm.exporting -> {}
            vm.resultUri != null -> vm.dismissResult()
            vm.panel != null -> {
                if (vm.recording) vm.stopRecording()
                vm.panel = null
            }
            vm.selection != null -> vm.selection = null
            else -> confirmExit = true
        }
    }

    // الشاشة تفضل صاحية أثناء التصدير
    val window = (context as? ComponentActivity)?.window
    DisposableEffect(vm.exporting) {
        if (vm.exporting) window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    LaunchedEffect(vm.message) {
        if (vm.message != null) {
            delay(3200)
            vm.clearMessage()
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            TopBar(vm, onClose = { confirmExit = true }, onExport = {
                if (vm.project.clips.isEmpty()) vm.message = "ضيف صورة أو فيديو الأول" else showExport = true
            })
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth().background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                PreviewArea(vm)
            }
            TransportRow(vm, onZoomOut = { dpPerSec = (dpPerSec / 1.4f).coerceAtLeast(1f) },
                onZoomIn = { dpPerSec = (dpPerSec * 1.4f).coerceAtMost(240f) })
            TimelineView(vm, dpPerSec, onAddMedia = { addMedia() }, modifier = Modifier.fillMaxWidth().height(178.dp))
            val p = vm.panel
            if (p != null) {
                PanelHost(vm, p, onClose = {
                    if (vm.recording) vm.stopRecording()
                    vm.panel = null
                }, onRequestRecord = { requestRecord() })
            } else {
                ToolBar(toolsFor(vm, addMedia, addAudio))
            }
        }

        // رسالة علوية
        val msg = vm.message
        if (msg != null) {
            Box(
                modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(top = 56.dp, start = 24.dp, end = 24.dp),
                contentAlignment = Alignment.TopCenter
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xEE2E3242))
                        .clickable { vm.clearMessage() }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(msg, color = VMColors.Text, fontSize = 13.sp)
                }
            }
        }

        if (vm.busy) {
            Box(
                Modifier.fillMaxSize().background(Color(0x66000000)).clickable(enabled = true) {},
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = VMColors.Accent)
            }
        }

        if (showExport) {
            ExportDialog(vm, onDismiss = { showExport = false }, onStart = {
                showExport = false
                vm.startExport()
            })
        }

        if (vm.exporting) ExportProgressOverlay(vm)

        val res = vm.resultUri
        if (res != null) ResultScreen(vm, res)

        val err = vm.exportError
        if (err != null && !vm.exporting) {
            AlertDialog(
                onDismissRequest = { vm.dismissResult() },
                confirmButton = { TextButton(onClick = { vm.dismissResult() }) { Text("حسنًا") } },
                title = { Text("تعذر التصدير") },
                text = { Text(err, fontSize = 13.sp) }
            )
        }

        if (confirmExit) {
            AlertDialog(
                onDismissRequest = { confirmExit = false },
                confirmButton = {
                    TextButton(onClick = {
                        confirmExit = false
                        vm.engine.pause()
                        vm.selection = null
                        vm.panel = null
                        vm.resetProject()
                        onExit()
                    }) { Text("خروج", color = VMColors.Danger) }
                },
                dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("إكمال التعديل") } },
                title = { Text("إغلاق المشروع؟") },
                text = { Text("المشروع غير محفوظ، وهيتمسح لو خرجت. صدّر الفيديو الأول لو خلصت.", fontSize = 13.sp) }
            )
        }
    }
}

@Composable
private fun TopBar(vm: EditorViewModel, onClose: () -> Unit, onExport: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(VMColors.Surface).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        GlyphButton("✕", true, onClose)
        Spacer(Modifier.weight(1f))
        GlyphButton("↶", vm.canUndo) { vm.undo() }
        GlyphButton("↷", vm.canRedo) { vm.redo() }
        Spacer(Modifier.size(6.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(18.dp))
                .background(VMColors.Accent)
                .clickable { onExport() }
                .padding(horizontal = 18.dp, vertical = 8.dp)
        ) {
            Text("تصدير", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun GlyphButton(glyph: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(glyph, color = if (enabled) VMColors.Text else Color(0xFF5A6076), fontSize = 22.sp)
    }
}

@Composable
private fun TransportRow(vm: EditorViewModel, onZoomOut: () -> Unit, onZoomIn: () -> Unit) {
    val engine = vm.engine
    val total = vm.project.totalMs
    Row(
        modifier = Modifier.fillMaxWidth().background(VMColors.Surface).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
                formatTime(engine.positionMs) + " / " + formatTime(total),
                color = VMColors.TextDim,
                fontSize = 12.sp
            )
        }
        Spacer(Modifier.weight(1f))
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(VMColors.Accent)
                .clickable { if (!vm.recording) engine.toggle() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (engine.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = "تشغيل",
                tint = Color.Black,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(Modifier.weight(1f))
        GlyphButton("−", true, onZoomOut)
        Text("تكبير", color = VMColors.TextDim, fontSize = 10.sp)
        GlyphButton("+", true, onZoomIn)
    }
}

// ------------------------------------------------------------------ أدوات الشريط السفلي

private fun toolsFor(vm: EditorViewModel, addMedia: () -> Unit, addAudio: () -> Unit): List<Tool> {
    val list = ArrayList<Tool>()
    val sel = vm.selection
    if (sel != null) {
        list += Tool(null, "إلغاء", glyph = "✕") { vm.selection = null }
    }
    when (sel) {
        is Selection.Clip -> {
            val c = vm.clipById(sel.id)
            if (c != null) {
                list += Tool(null, "تقسيم", glyph = "✂") { vm.splitAtPlayhead() }
                if (c.isImage) {
                    list += Tool(null, "المدة", glyph = "⏱") { vm.panel = Panel.TRIM_IMAGE }
                } else {
                    list += Tool(null, "السرعة", glyph = "⏩") { vm.panel = Panel.SPEED }
                    list += Tool(null, "الصوت", glyph = "🔊") { vm.panel = Panel.VOLUME }
                    list += Tool(null, "فصل الصوت", glyph = "🎼") { vm.extractAudio() }
                    list += Tool(null, if (c.muted) "تشغيل الصوت" else "كتم", glyph = if (c.muted) "🔈" else "🔇") {
                        vm.updateClip(c.id) { it.copy(muted = !it.muted) }
                    }
                }
                list += Tool(null, "فلتر", glyph = "🎨") { vm.panel = Panel.FILTER }
                list += Tool(null, "ألوان", glyph = "🎚") { vm.panel = Panel.ADJUST }
                list += Tool(null, "حركة", glyph = "✨") { vm.panel = Panel.ANIM }
                list += Tool(null, "تدوير", glyph = "⟳") { vm.updateClip(c.id) { it.copy(rotation = (it.rotation + 90) % 360) } }
                list += Tool(null, "قلب أفقي", glyph = "⇋", active = c.flipH) { vm.updateClip(c.id) { it.copy(flipH = !it.flipH) } }
                list += Tool(null, "ملء الإطار", glyph = "⛶", active = c.fill) { vm.updateClip(c.id) { it.copy(fill = !it.fill) } }
                list += Tool(null, "للخلف", glyph = "▶") { vm.moveSelectedClip(-1) }
                list += Tool(null, "للأمام", glyph = "◀") { vm.moveSelectedClip(1) }
                list += Tool(null, "نسخ", glyph = "⧉") { vm.duplicateSelected() }
                list += Tool(null, "حذف", glyph = "🗑", danger = true) { vm.deleteSelected() }
            }
        }
        is Selection.Audio -> {
            list += Tool(null, "تقسيم", glyph = "✂") { vm.splitAtPlayhead() }
            list += Tool(null, "المستوى", glyph = "🔊") { vm.panel = Panel.AUDIO_VOLUME }
            list += Tool(null, "تلاشي", glyph = "📉") { vm.panel = Panel.AUDIO_FADE }
            list += Tool(null, "نسخ", glyph = "⧉") { vm.duplicateSelected() }
            list += Tool(null, "حذف", glyph = "🗑", danger = true) { vm.deleteSelected() }
        }
        is Selection.Text -> {
            val t = vm.textById(sel.id)
            if (t != null && !t.isSticker) list += Tool(null, "تعديل", glyph = "✎") { vm.panel = Panel.TEXT_EDIT }
            list += Tool(null, "النمط", glyph = "🎨") { vm.panel = Panel.TEXT_STYLE }
            list += Tool(null, "نسخ", glyph = "⧉") { vm.duplicateSelected() }
            list += Tool(null, "حذف", glyph = "🗑", danger = true) { vm.deleteSelected() }
        }
        null -> {
            list += Tool(null, "وسائط", glyph = "🖼") { addMedia() }
            list += Tool(null, "صوت", glyph = "🎵") { addAudio() }
            list += Tool(null, "تسجيل", glyph = "🎙") { vm.panel = Panel.RECORD }
            list += Tool(null, "نص", glyph = "T") { vm.addText() }
            list += Tool(null, "ملصقات", glyph = "😀") { vm.panel = Panel.STICKERS }
            list += Tool(null, "الأبعاد", glyph = "▭") { vm.panel = Panel.ASPECT }
        }
    }
    return list
}

// ------------------------------------------------------------------ التصدير

@Composable
private fun ExportDialog(vm: EditorViewModel, onDismiss: () -> Unit, onStart: () -> Unit) {
    val cfg = vm.exportConfig
    val aspect = vm.project.aspect
    val (w, h) = cfg.size(aspect)
    val bytes = cfg.bitrate(aspect).toLong() / 8L * (vm.project.totalMs / 1000L) + (128_000L / 8L) * (vm.project.totalMs / 1000L)
    val mb = bytes / 1_048_576f
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onStart) { Text("ابدأ التصدير", color = VMColors.Accent, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        title = { Text("إعدادات التصدير") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("الدقة", color = VMColors.TextDim, fontSize = 12.sp)
                ChipRow(ExportRes.entries.toList(), cfg.res, { it.label }) { vm.exportConfig = cfg.copy(res = it) }
                Text("معدل الإطارات", color = VMColors.TextDim, fontSize = 12.sp)
                ChipRow(listOf(24, 30, 60), cfg.fps, { "$it fps" }) { vm.exportConfig = cfg.copy(fps = it) }
                Text("الجودة", color = VMColors.TextDim, fontSize = 12.sp)
                ChipRow(ExportQuality.entries.toList(), cfg.quality, { it.label }) { vm.exportConfig = cfg.copy(quality = it) }
                Text(
                    "${w}×${h} · المدة " + formatTime(vm.project.totalMs) + " · الحجم التقريبي " +
                        String.format(Locale.US, "%.0f MB", mb),
                    color = VMColors.Text,
                    fontSize = 12.sp
                )
                Text("هيتحفظ في المعرض داخل مجلد VideoMaker. سيب الشاشة مفتوحة أثناء التصدير.", color = VMColors.TextDim, fontSize = 11.sp)
            }
        }
    )
}

@Composable
private fun ExportProgressOverlay(vm: EditorViewModel) {
    Box(
        Modifier.fillMaxSize().background(Color(0xF0101218)).clickable(enabled = true) {},
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("جاري تصدير الفيديو", color = VMColors.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                String.format(Locale.US, "%d%%", (vm.exportProgress * 100).toInt()),
                color = VMColors.Accent,
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold
            )
            LinearProgressIndicator(
                progress = { vm.exportProgress.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = VMColors.Accent,
                trackColor = VMColors.Surface3
            )
            Text(
                "متقفلش التطبيق ولا الشاشة لحد ما يخلص. الفيديو الطويل بياخد وقت.",
                color = VMColors.TextDim,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
            SmallButton("إلغاء") { vm.cancelExport() }
        }
    }
}

@Composable
private fun ResultScreen(vm: EditorViewModel, uri: Uri) {
    val context = LocalContext.current
    Column(
        modifier = Modifier.fillMaxSize().background(VMColors.Bg).statusBarsPadding().navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "✓ تم حفظ الفيديو في المعرض",
            color = VMColors.Accent,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(16.dp)
        )
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth().background(Color.Black),
            factory = { ctx ->
                VideoView(ctx).apply {
                    val mc = MediaController(ctx)
                    mc.setAnchorView(this)
                    setMediaController(mc)
                    setVideoURI(uri)
                    setOnPreparedListener { it.isLooping = false; start() }
                }
            }
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(VMColors.Accent)
                    .clickable {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "video/mp4"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(send, "مشاركة الفيديو"))
                    }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) { Text("مشاركة", color = Color.Black, fontWeight = FontWeight.Bold) }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(VMColors.Surface3)
                    .clickable { vm.dismissResult() }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) { Text("رجوع للتعديل", color = VMColors.Text) }
        }
    }
}
