package com.mohamed.videomaker

import android.graphics.Matrix
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableString
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import com.google.common.collect.ImmutableList
import java.nio.ByteBuffer

// ======================= الصوت =======================

/** يتحكم في مستوى الصوت مع تلاشي دخول/خروج (PCM 16-bit). */
class FadeVolumeProcessor(
    private val volume: Float,
    private val fadeInMs: Long,
    private val fadeOutMs: Long,
    private val totalMs: Long
) : BaseAudioProcessor() {

    private var sampleRate = 44100
    private var channels = 2
    private var frameCount = 0L

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        sampleRate = inputAudioFormat.sampleRate
        channels = inputAudioFormat.channelCount.coerceAtLeast(1)
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        val frameBytes = 2 * channels
        val frames = size / frameBytes
        val simple = fadeInMs <= 0L && fadeOutMs <= 0L
        for (f in 0 until frames) {
            var gain = volume
            if (!simple) {
                val tMs = (frameCount * 1000L) / sampleRate
                if (fadeInMs > 0L && tMs < fadeInMs) gain *= tMs.toFloat() / fadeInMs
                val left = totalMs - tMs
                if (fadeOutMs > 0L && left < fadeOutMs) gain *= (left.coerceAtLeast(0L)).toFloat() / fadeOutMs
            }
            for (c in 0 until channels) {
                val s = inputBuffer.getShort().toInt()
                out.putShort((s * gain).toInt().coerceIn(-32768, 32767).toShort())
            }
            frameCount++
        }
        // بايتات متبقية (لو الحجم مش مضاعف للإطار)
        while (inputBuffer.hasRemaining()) out.put(inputBuffer.get())
        out.flip()
    }
}

// ======================= الفيديو: حركات وانتقالات =======================

private fun edgeFactor(tUs: Long, lengthUs: Long): Float {
    val edge = minOf(500_000L, lengthUs / 3).coerceAtLeast(1L)
    val a = tUs.toFloat() / edge
    val b = (lengthUs - tUs).toFloat() / edge
    return minOf(1f, a, b).coerceIn(0f, 1f)
}

/** تلاشي من/إلى الأسود في أول وآخر المقطع. */
class FadeEffect(private val lengthUs: Long) : RgbMatrix {
    private var baseUs = -1L

    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
        if (baseUs < 0) baseUs = presentationTimeUs
        val f = edgeFactor(presentationTimeUs - baseUs, lengthUs)
        return floatArrayOf(
            f, 0f, 0f, 0f,
            0f, f, 0f, 0f,
            0f, 0f, f, 0f,
            0f, 0f, 0f, 1f
        )
    }
}

/** تكبير خفيف في أول وآخر المقطع. */
class ZoomEffect(private val lengthUs: Long) : MatrixTransformation {
    private var baseUs = -1L

    override fun getMatrix(presentationTimeUs: Long): Matrix {
        if (baseUs < 0) baseUs = presentationTimeUs
        val f = edgeFactor(presentationTimeUs - baseUs, lengthUs)
        val s = 0.6f + 0.4f * f
        return Matrix().apply { setScale(s, s) }
    }
}

/** تكبير/تصغير تدريجي على طول المقطع (Ken Burns). */
class ScaleOverTimeEffect(
    private val lengthUs: Long,
    private val from: Float,
    private val to: Float
) : MatrixTransformation {
    private var baseUs = -1L

    override fun getMatrix(presentationTimeUs: Long): Matrix {
        if (baseUs < 0) baseUs = presentationTimeUs
        val p = ((presentationTimeUs - baseUs).toFloat() / lengthUs.coerceAtLeast(1L)).coerceIn(0f, 1f)
        val s = from + (to - from) * p
        return Matrix().apply { setScale(s, s) }
    }
}

/** مصفوفة ألوان ثابتة (صف-بصف) تتحول لـ column-major. */
private class StaticColorMatrix(rowMajor: FloatArray) : RgbMatrix {
    private val columnMajor = FloatArray(16).also { out ->
        for (r in 0 until 4) for (c in 0 until 4) out[c * 4 + r] = rowMajor[r * 4 + c]
    }

    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray = columnMajor
}

private val SEPIA_MATRIX = floatArrayOf(
    0.393f, 0.769f, 0.189f, 0f,
    0.349f, 0.686f, 0.168f, 0f,
    0.272f, 0.534f, 0.131f, 0f,
    0f, 0f, 0f, 1f
)

/** كل تأثيرات المقطع بالترتيب: تدوير/قلب → ألوان → مقاس → حركة. */
fun clipVideoEffects(clip: VisualClip, frameW: Int, frameH: Int): List<Effect> {
    val list = mutableListOf<Effect>()

    if (clip.rotation != 0 || clip.flipH || clip.flipV) {
        val b = ScaleAndRotateTransformation.Builder()
        b.setScale(if (clip.flipH) -1f else 1f, if (clip.flipV) -1f else 1f)
        b.setRotationDegrees(-clip.rotation.toFloat())
        list.add(b.build())
    }

    val f = clip.filter
    if (f.gray) list.add(RgbFilter.createGrayscaleFilter())
    if (f.sepia) list.add(StaticColorMatrix(SEPIA_MATRIX))

    val a = Adjust(
        brightness = (f.adjust.brightness + clip.adjust.brightness).coerceIn(-1f, 1f),
        contrast = (f.adjust.contrast + clip.adjust.contrast).coerceIn(-1f, 1f),
        saturation = (f.adjust.saturation + clip.adjust.saturation).coerceIn(-1f, 1f),
        warmth = (f.adjust.warmth + clip.adjust.warmth).coerceIn(-1f, 1f)
    )
    if (a.warmth != 0f) {
        list.add(
            RgbAdjustment.Builder()
                .setRedScale(1f + 0.18f * a.warmth)
                .setBlueScale(1f - 0.18f * a.warmth)
                .build()
        )
    }
    if (a.saturation != 0f) {
        list.add(HslAdjustment.Builder().adjustSaturation(a.saturation * 100f).build())
    }
    if (a.contrast != 0f) list.add(Contrast(a.contrast))
    if (a.brightness != 0f) list.add(Brightness(a.brightness))

    list.add(
        Presentation.createForWidthAndHeight(
            frameW,
            frameH,
            if (clip.fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT
        )
    )

    val lengthUs = clip.outMs * 1000L
    when (clip.anim) {
        ClipAnim.FADE -> list.add(FadeEffect(lengthUs))
        ClipAnim.ZOOM -> list.add(ZoomEffect(lengthUs))
        ClipAnim.SLOW_ZOOM_IN -> list.add(ScaleOverTimeEffect(lengthUs, 1f, 1.15f))
        ClipAnim.SLOW_ZOOM_OUT -> list.add(ScaleOverTimeEffect(lengthUs, 1.15f, 1f))
        ClipAnim.NONE -> Unit
    }
    return list
}

// ======================= السرعة (بالـ reflection لأن الواجهة تختلف بين الإصدارات) =======================

/** تأثير فيديو لتغيير السرعة، أو null لو غير متاح في الإصدار الحالي. */
fun speedVideoEffect(speed: Float): Effect? {
    return try {
        val cls = Class.forName("androidx.media3.effect.SpeedChangeEffect")
        cls.getConstructor(java.lang.Float.TYPE).newInstance(speed) as Effect
    } catch (e: Throwable) {
        null
    }
}

fun speedAudioProcessor(speed: Float): AudioProcessor {
    val p = SonicAudioProcessor()
    p.setSpeed(speed)
    p.setPitch(1f)
    return p
}

// ======================= النصوص والملصقات =======================

private fun typefaceFor(item: TextItem): Typeface {
    val style = when {
        item.bold && item.italic -> Typeface.BOLD_ITALIC
        item.bold -> Typeface.BOLD
        item.italic -> Typeface.ITALIC
        else -> Typeface.NORMAL
    }
    return Typeface.create(item.font.family, style)
}

/** يقسم النص لأسطر بحيث لا يتجاوز عرض الإطار. */
private fun wrapText(text: String, sizePx: Float, tf: Typeface, maxWidthPx: Int): String {
    if (text.isEmpty()) return " "
    val paint = TextPaint().apply {
        textSize = sizePx
        typeface = tf
        isAntiAlias = true
    }
    val layout = StaticLayout.Builder
        .obtain(text, 0, text.length, paint, maxWidthPx.coerceAtLeast(50))
        .setAlignment(Layout.Alignment.ALIGN_CENTER)
        .build()
    val sb = StringBuilder()
    for (i in 0 until layout.lineCount) {
        var line = text.substring(layout.getLineStart(i), layout.getLineEnd(i))
        line = line.trimEnd('\n', ' ')
        if (i > 0) sb.append('\n')
        sb.append(line)
    }
    return sb.toString()
}

/** نص/ملصق يظهر في الفترة [startMs, endMs] فقط. */
class TimedTextOverlay(
    private val item: TextItem,
    private val frameW: Int,
    private val frameH: Int
) : TextOverlay() {

    private val spannable: SpannableString

    init {
        val sizePx = (item.sizeFrac * frameH).coerceAtLeast(10f)
        val tf = typefaceFor(item)
        val wrapped = wrapText(item.text, sizePx, tf, (frameW * 0.9f).toInt())
        val s = SpannableString(wrapped)
        val end = wrapped.length
        val flags = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        s.setSpan(AbsoluteSizeSpan(sizePx.toInt(), false), 0, end, flags)
        s.setSpan(ForegroundColorSpan(item.color), 0, end, flags)
        if ((item.bgColor ushr 24) != 0) s.setSpan(BackgroundColorSpan(item.bgColor), 0, end, flags)
        s.setSpan(TypefaceSpan(tf), 0, end, flags)
        spannable = s
    }

    override fun getText(presentationTimeUs: Long): SpannableString = spannable

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val tMs = presentationTimeUs / 1000L
        var alpha = if (tMs in item.startMs until item.endMs) 1f else 0f
        if (alpha > 0f && item.anim == TextAnim.FADE) {
            val edge = minOf(300L, item.durationMs / 3).coerceAtLeast(1L)
            val a = (tMs - item.startMs).toFloat() / edge
            val b = (item.endMs - tMs).toFloat() / edge
            alpha = minOf(1f, a, b).coerceIn(0f, 1f)
        }
        return OverlaySettings.Builder()
            .setOverlayFrameAnchor(0f, 0f)
            .setBackgroundFrameAnchor(item.x * 2f - 1f, 1f - item.y * 2f)
            .setRotationDegrees(-item.rotation)
            .setAlphaScale(alpha)
            .build()
    }
}

/** تأثير واحد يحمل كل النصوص (يتطبّق على الفيديو النهائي). */
fun textOverlaysEffect(items: List<TextItem>, frameW: Int, frameH: Int): Effect? {
    if (items.isEmpty()) return null
    val overlays = ArrayList<TextureOverlay>()
    for (t in items) overlays.add(TimedTextOverlay(t, frameW, frameH))
    val list: ImmutableList<TextureOverlay> = ImmutableList.copyOf(overlays)
    return OverlayEffect(list)
}
