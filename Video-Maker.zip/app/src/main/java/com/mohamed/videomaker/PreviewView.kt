package com.mohamed.videomaker

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.view.TextureView
import android.view.View
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.offset
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.ColorMatrix as ComposeColorMatrix

/** مصفوفة ألوان تقريبية للمعاينة (نفس منطق التصدير). */
fun clipColorMatrix(clip: VisualClip): ColorMatrix? {
    val f = clip.filter
    val a = Adjust(
        brightness = (f.adjust.brightness + clip.adjust.brightness).coerceIn(-1f, 1f),
        contrast = (f.adjust.contrast + clip.adjust.contrast).coerceIn(-1f, 1f),
        saturation = (f.adjust.saturation + clip.adjust.saturation).coerceIn(-1f, 1f),
        warmth = (f.adjust.warmth + clip.adjust.warmth).coerceIn(-1f, 1f)
    )
    if (!f.gray && !f.sepia && a.isNeutral) return null
    val m = ColorMatrix()
    if (f.gray) m.postConcat(ColorMatrix().apply { setSaturation(0f) })
    if (f.sepia) {
        m.postConcat(
            ColorMatrix(
                floatArrayOf(
                    0.393f, 0.769f, 0.189f, 0f, 0f,
                    0.349f, 0.686f, 0.168f, 0f, 0f,
                    0.272f, 0.534f, 0.131f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }
    if (a.warmth != 0f) {
        m.postConcat(
            ColorMatrix(
                floatArrayOf(
                    1f + 0.18f * a.warmth, 0f, 0f, 0f, 0f,
                    0f, 1f, 0f, 0f, 0f,
                    0f, 0f, 1f - 0.18f * a.warmth, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }
    if (a.saturation != 0f) m.postConcat(ColorMatrix().apply { setSaturation(1f + a.saturation) })
    if (a.contrast != 0f) {
        val c = 1f + a.contrast
        val t = 128f * (1f - c)
        m.postConcat(
            ColorMatrix(
                floatArrayOf(
                    c, 0f, 0f, 0f, t,
                    0f, c, 0f, 0f, t,
                    0f, 0f, c, 0f, t,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }
    if (a.brightness != 0f) {
        val b = a.brightness * 255f
        m.postConcat(
            ColorMatrix(
                floatArrayOf(
                    1f, 0f, 0f, 0f, b,
                    0f, 1f, 0f, 0f, b,
                    0f, 0f, 1f, 0f, b,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }
    return m
}

private fun edge(localMs: Long, lengthMs: Long): Float {
    val e = minOf(500L, lengthMs / 3).coerceAtLeast(1L)
    val a = localMs.toFloat() / e
    val b = (lengthMs - localMs).toFloat() / e
    return minOf(1f, a, b).coerceIn(0f, 1f)
}

/** منطقة المعاينة كاملة: إطار بنسبة المشروع + المقطع النشط + النصوص. */
@Composable
fun PreviewArea(vm: EditorViewModel, modifier: Modifier = Modifier) {
    val project = vm.project
    val t = vm.engine.positionMs
    val density = LocalDensity.current

    BoxWithConstraints(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val ar = project.aspect.ratio
        val w = if (maxWidth / ar <= maxHeight) maxWidth else maxHeight * ar
        val h = w / ar
        val cw = with(density) { w.toPx() }
        val ch = with(density) { h.toPx() }

        Box(
            modifier = Modifier
                .size(w, h)
                .clipToBounds()
                .background(Color.Black)
                .pointerInput(Unit) {
                    detectTapGestures { vm.selection = null; vm.panel = null }
                }
        ) {
            val ac = vm.engine.activeClip(t)
            if (ac != null) {
                ClipLayer(ac.first, t - ac.second, cw, ch, vm)
            } else {
                Text(
                    "أضف فيديو أو صورة للبدء",
                    color = VMColors.TextDim,
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            for (item in project.texts) {
                val selected = (vm.selection as? Selection.Text)?.id == item.id
                val visible = t >= item.startMs && t < item.endMs
                if (visible || selected) {
                    TextLayer(item, t, visible, selected, cw, ch, vm)
                }
            }
        }
    }
}

@Composable
private fun ClipLayer(clip: VisualClip, local: Long, cw: Float, ch: Float, vm: EditorViewModel) {
    val density = LocalDensity.current
    val rotated = clip.rotation == 90 || clip.rotation == 270
    var ca = if (clip.srcWidth > 0 && clip.srcHeight > 0) clip.srcWidth.toFloat() / clip.srcHeight else 16f / 9f
    if (ca <= 0f) ca = 16f / 9f
    // نسبة المحتوى بعد التدوير
    val ea = if (rotated) 1f / ca else ca

    var w: Float
    var h: Float
    val fitW = cw
    val fitH = cw / ea
    if (clip.fill) {
        if (fitH >= ch) {
            w = fitW; h = fitH
        } else {
            h = ch; w = ch * ea
        }
    } else {
        if (fitH <= ch) {
            w = fitW; h = fitH
        } else {
            h = ch; w = ch * ea
        }
    }
    // أبعاد الصندوق قبل التدوير
    val boxW = if (rotated) h else w
    val boxH = if (rotated) w else h

    var alpha = 1f
    var scale = 1f
    val p = (local.toFloat() / clip.outMs.coerceAtLeast(1L)).coerceIn(0f, 1f)
    when (clip.anim) {
        ClipAnim.FADE -> alpha = edge(local, clip.outMs)
        ClipAnim.ZOOM -> scale = 0.6f + 0.4f * edge(local, clip.outMs)
        ClipAnim.SLOW_ZOOM_IN -> scale = 1f + 0.15f * p
        ClipAnim.SLOW_ZOOM_OUT -> scale = 1.15f - 0.15f * p
        ClipAnim.NONE -> Unit
    }

    val matrix = clipColorMatrix(clip)

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(with(density) { boxW.toDp() }, with(density) { boxH.toDp() })
                .graphicsLayer {
                    rotationZ = clip.rotation.toFloat()
                    scaleX = (if (clip.flipH) -1f else 1f) * scale
                    scaleY = (if (clip.flipV) -1f else 1f) * scale
                    this.alpha = alpha
                }
        ) {
            if (clip.isImage) {
                val bmp = clip.thumb
                if (bmp != null) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.FillBounds,
                        colorFilter = if (matrix != null) ColorFilter.colorMatrix(ComposeColorMatrix(matrix.array)) else null,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            } else {
                val key = clip.filter.name + clip.adjust.toString()
                AndroidView(
                    factory = { ctx ->
                        TextureView(ctx).also { tv -> vm.engine.video.setVideoTextureView(tv) }
                    },
                    update = { tv ->
                        if (tv.tag != key) {
                            tv.tag = key
                            if (matrix == null) {
                                tv.setLayerType(View.LAYER_TYPE_NONE, null)
                            } else {
                                val paint = Paint()
                                paint.colorFilter = ColorMatrixColorFilter(matrix)
                                tv.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
private fun TextLayer(
    item: TextItem,
    t: Long,
    visible: Boolean,
    selected: Boolean,
    cw: Float,
    ch: Float,
    vm: EditorViewModel
) {
    val density = LocalDensity.current
    var size by remember { mutableStateOf(IntSize.Zero) }

    var alpha = if (visible) 1f else 0.35f
    if (visible && item.anim == TextAnim.FADE) {
        val e = minOf(300L, item.durationMs / 3).coerceAtLeast(1L)
        val a = (t - item.startMs).toFloat() / e
        val b = (item.endMs - t).toFloat() / e
        alpha = minOf(1f, a, b).coerceIn(0f, 1f)
    }

    val fontSize = with(density) { (item.sizeFrac * ch).toSp() }
    val family = when (item.font) {
        TextFont.SANS -> FontFamily.SansSerif
        TextFont.SERIF -> FontFamily.Serif
        TextFont.CONDENSED -> FontFamily.SansSerif
        TextFont.MONO -> FontFamily.Monospace
        TextFont.CURSIVE -> FontFamily.Cursive
        TextFont.CASUAL -> FontFamily.Default
    }

    Box(
        modifier = Modifier
            .offset {
                IntOffset(
                    (item.x * cw - size.width / 2f).toInt(),
                    (item.y * ch - size.height / 2f).toInt()
                )
            }
            .onSizeChanged { size = it }
            .pointerInput(item.id) {
                detectTapGestures { vm.selection = Selection.Text(item.id) }
            }
            .pointerInput(item.id, selected) {
                if (selected) {
                    detectTransformGestures { _, pan, zoom, rot ->
                        vm.updateText(item.id, false) {
                            it.copy(
                                x = (it.x + pan.x / cw).coerceIn(0f, 1f),
                                y = (it.y + pan.y / ch).coerceIn(0f, 1f),
                                sizeFrac = (it.sizeFrac * zoom).coerceIn(0.02f, 0.5f),
                                rotation = it.rotation + rot
                            )
                        }
                    }
                }
            }
            .graphicsLayer {
                rotationZ = item.rotation
                this.alpha = alpha
            }
            .then(if (selected) Modifier.border(1.dp, VMColors.Accent) else Modifier)
    ) {
        Text(
            text = item.text,
            color = Color(item.color),
            fontSize = fontSize,
            fontWeight = if (item.bold) FontWeight.Bold else FontWeight.Normal,
            fontStyle = if (item.italic) FontStyle.Italic else FontStyle.Normal,
            fontFamily = family,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .widthIn(max = with(density) { (cw * 0.9f).toDp() })
                .background(Color(item.bgColor))
                .padding(horizontal = 2.dp)
        )
    }
}
