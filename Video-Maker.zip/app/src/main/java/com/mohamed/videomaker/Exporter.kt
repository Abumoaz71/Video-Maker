package com.mohamed.videomaker

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.core.net.toUri
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** يبني الـ Composition ويشغّل Transformer (لازم يتنادى كله من الـ Main thread). */
class Exporter(private val context: Context) {

    interface Callback {
        fun onDone(file: File)
        fun onError(message: String)
    }

    private var transformer: Transformer? = null

    /** ملف صوت صامت (ستيريو 44.1k) بالمدة المطلوبة، لإزاحة بداية الصوت. */
    private fun silenceWav(durationMs: Long): Uri {
        val capped = durationMs.coerceIn(100L, 30L * 60_000L)
        val file = File(context.cacheDir, "silence_$capped.wav")
        if (!file.exists() || file.length() < 44) {
            val sampleRate = 44100
            val frames = capped * sampleRate / 1000L
            val dataBytes = frames * 4L
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray())
            header.putInt((36L + dataBytes).toInt())
            header.put("WAVE".toByteArray())
            header.put("fmt ".toByteArray())
            header.putInt(16)
            header.putShort(1)
            header.putShort(2)
            header.putInt(sampleRate)
            header.putInt(sampleRate * 4)
            header.putShort(4)
            header.putShort(16)
            header.put("data".toByteArray())
            header.putInt(dataBytes.toInt())
            FileOutputStream(file).use { out ->
                out.write(header.array())
                val chunk = ByteArray(65536)
                var left = dataBytes
                while (left > 0) {
                    val n = minOf(left, chunk.size.toLong()).toInt()
                    out.write(chunk, 0, n)
                    left -= n
                }
            }
        }
        return file.toUri()
    }

    private fun forceAudioTrack(builder: Any) {
        try {
            builder.javaClass
                .getMethod("experimentalSetForceAudioTrack", java.lang.Boolean.TYPE)
                .invoke(builder, true)
        } catch (e: Throwable) {
            // الدالة مش موجودة في الـ builder ده، عادي
        }
    }

    fun buildComposition(p: Project, cfg: ExportConfig): Composition {
        val (frameW, frameH) = cfg.size(p.aspect)
        val total = p.totalMs

        // ---------- المسار الرئيسي ----------
        val items = p.clips.map { clip ->
            val mediaItem = MediaItem.Builder().setUri(clip.uri).apply {
                if (clip.isImage) {
                    setImageDurationMs(clip.imageMs)
                } else {
                    setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(clip.trimStartMs)
                            .setEndPositionMs(clip.trimEndMs)
                            .build()
                    )
                }
            }.build()

            val videoEffects = mutableListOf<Effect>()
            val audioProcs = mutableListOf<AudioProcessor>()
            val removeAudio = !clip.isImage && (clip.muted || clip.volume <= 0f)

            var speedOk = false
            if (!clip.isImage && clip.speed != 1f) {
                val se = speedVideoEffect(clip.speed)
                if (se != null) {
                    videoEffects.add(se)
                    speedOk = true
                }
            }
            if (speedOk && !removeAudio) audioProcs.add(speedAudioProcessor(clip.speed))
            if (!clip.isImage && !removeAudio && clip.volume != 1f) {
                audioProcs.add(FadeVolumeProcessor(clip.volume, 0L, 0L, clip.outMs))
            }
            videoEffects.addAll(clipVideoEffects(clip, frameW, frameH))

            val builder = EditedMediaItem.Builder(mediaItem)
                .setEffects(Effects(audioProcs, videoEffects))
                .setRemoveAudio(removeAudio)
            if (clip.isImage) {
                val moving = clip.anim == ClipAnim.SLOW_ZOOM_IN || clip.anim == ClipAnim.SLOW_ZOOM_OUT
                val fps = if (clip.imageMs > 20_000L && !moving) 10 else cfg.fps
                builder.setFrameRate(fps)
            }
            builder.build()
        }

        val mainBuilder = EditedMediaItemSequence.Builder(items)
        forceAudioTrack(mainBuilder)
        val sequences = mutableListOf(mainBuilder.build())

        // ---------- مسارات الصوت ----------
        for (a in p.audios) {
            if (a.startMs >= total) continue
            val usable = minOf(a.lengthMs, total - a.startMs)
            if (usable < 100L) continue
            val trimEnd = a.trimStartMs + usable

            val audioItem = EditedMediaItem.Builder(
                MediaItem.Builder().setUri(a.uri).setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(a.trimStartMs)
                        .setEndPositionMs(trimEnd)
                        .build()
                ).build()
            )
                .setRemoveVideo(true)
                .setEffects(
                    Effects(
                        listOf<AudioProcessor>(
                            FadeVolumeProcessor(a.volume, a.fadeInMs, a.fadeOutMs, usable)
                        ),
                        emptyList()
                    )
                )
                .build()

            val seqItems = mutableListOf<EditedMediaItem>()
            if (a.startMs > 0L) {
                seqItems.add(EditedMediaItem.Builder(MediaItem.fromUri(silenceWav(a.startMs))).build())
            }
            seqItems.add(audioItem)
            sequences.add(EditedMediaItemSequence.Builder(seqItems).build())
        }

        // ---------- النصوص ----------
        val compBuilder = Composition.Builder(sequences)
        forceAudioTrack(compBuilder)
        val visibleTexts = p.texts.filter { it.startMs < total }
        val textEffect = textOverlaysEffect(visibleTexts, frameW, frameH)
        if (textEffect != null) {
            compBuilder.setEffects(Effects(emptyList(), listOf(textEffect)))
        }
        return compBuilder.build()
    }

    fun start(project: Project, cfg: ExportConfig, outFile: File, callback: Callback) {
        val composition = buildComposition(project, cfg)

        val encoderSettings = VideoEncoderSettings.Builder()
            .setBitrate(cfg.bitrate(project.aspect))
            .build()
        val encoderFactory = DefaultEncoderFactory.Builder(context)
            .setRequestedVideoEncoderSettings(encoderSettings)
            .build()

        val t = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    callback.onDone(outFile)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    callback.onError(exportException.message ?: "حصل خطأ أثناء التصدير")
                }
            })
            .build()
        transformer = t
        if (outFile.exists()) outFile.delete()
        t.start(composition, outFile.absolutePath)
    }

    /** نسبة التقدم من 0 إلى 1 (أو -1 لو لسه مش متاحة). */
    fun progress(): Float {
        val t = transformer ?: return -1f
        val holder = ProgressHolder()
        val state = t.getProgress(holder)
        return if (state == Transformer.PROGRESS_STATE_AVAILABLE) holder.progress / 100f else -1f
    }

    fun cancel() {
        transformer?.cancel()
        transformer = null
    }

    companion object {
        /** ينسخ الفيديو النهائي لمعرض الصور (Movies/VideoMaker). */
        fun saveToGallery(context: Context, file: File): Uri? {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(
                    MediaStore.Video.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_MOVIES + "/VideoMaker"
                )
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: return null
            resolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        }
    }
}
