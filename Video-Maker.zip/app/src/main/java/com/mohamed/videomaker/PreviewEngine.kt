package com.mohamed.videomaker

import android.content.Context
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * محرك المعاينة: ساعة موحدة (positionMs) والمشغلات كلها تتبعها.
 * - مشغل فيديو واحد بقائمة تشغيل لمقاطع الفيديو فقط (الصور بتتعرض من الواجهة).
 * - مشغل صوت لكل عنصر صوتي.
 */
class PreviewEngine(private val context: Context, private val scope: CoroutineScope) {

    val video: ExoPlayer = ExoPlayer.Builder(context).build().also {
        it.setPauseAtEndOfMediaItems(true)
    }

    private val audioPlayers = HashMap<Long, ExoPlayer>()
    private val audioKeys = HashMap<Long, String>()

    var positionMs by mutableLongStateOf(0L)
        private set
    var playing by mutableStateOf(false)
        private set

    private var project = Project()
    private var videoIds: List<Long> = emptyList()
    private var videoKey = ""
    private var job: Job? = null
    private var lastTick = 0L

    // ---------- المشروع ----------

    fun setProject(p: Project) {
        project = p

        val videoClips = p.clips.filter { !it.isImage }
        val key = videoClips.joinToString("|") { "${it.id}:${it.uri}:${it.trimStartMs}:${it.trimEndMs}" }
        if (key != videoKey) {
            videoKey = key
            videoIds = videoClips.map { it.id }
            val items = videoClips.map { c ->
                MediaItem.Builder().setUri(c.uri).setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.trimStartMs)
                        .setEndPositionMs(c.trimEndMs)
                        .build()
                ).build()
            }
            video.playWhenReady = false
            video.setMediaItems(items)
            if (items.isNotEmpty()) video.prepare()
        }

        // مشغلات الصوت
        val alive = p.audios.map { it.id }.toSet()
        val gone = audioPlayers.keys.filter { it !in alive }
        for (id in gone) {
            audioPlayers.remove(id)?.release()
            audioKeys.remove(id)
        }
        for (a in p.audios) {
            val k = "${a.uri}:${a.trimStartMs}:${a.trimEndMs}"
            if (audioKeys[a.id] != k) {
                audioPlayers.remove(a.id)?.release()
                val pl = ExoPlayer.Builder(context).build()
                pl.setMediaItem(
                    MediaItem.Builder().setUri(a.uri).setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(a.trimStartMs)
                            .setEndPositionMs(a.trimEndMs)
                            .build()
                    ).build()
                )
                pl.prepare()
                pl.playWhenReady = false
                audioPlayers[a.id] = pl
                audioKeys[a.id] = k
            }
        }

        if (positionMs > p.totalMs) positionMs = p.totalMs
        syncAll(true)
    }

    // ---------- التحكم ----------

    fun play() {
        val total = project.totalMs
        if (total <= 0L) return
        if (positionMs >= total) positionMs = 0L
        playing = true
        lastTick = SystemClock.elapsedRealtime()
        syncAll(true)
        job?.cancel()
        job = scope.launch {
            while (isActive) {
                delay(40)
                tick()
            }
        }
    }

    fun pause() {
        playing = false
        job?.cancel()
        job = null
        syncAll(false)
    }

    fun toggle() {
        if (playing) pause() else play()
    }

    fun seekTo(ms: Long) {
        positionMs = ms.coerceIn(0L, project.totalMs)
        syncAll(true)
    }

    fun release() {
        job?.cancel()
        video.release()
        for (p in audioPlayers.values) p.release()
        audioPlayers.clear()
    }

    // ---------- داخلي ----------

    /** المقطع النشط عند الزمن t مع بدايته. */
    fun activeClip(t: Long): Pair<VisualClip, Long>? {
        var start = 0L
        val clips = project.clips
        for (c in clips) {
            val end = start + c.outMs
            if (t >= start && t < end) return Pair(c, start)
            start = end
        }
        if (clips.isNotEmpty() && t >= start) {
            val last = clips.last()
            return Pair(last, start - last.outMs)
        }
        return null
    }

    private fun tick() {
        val now = SystemClock.elapsedRealtime()
        val dt = now - lastTick
        lastTick = now
        val total = project.totalMs

        var newPos = positionMs + dt
        val ac = activeClip(positionMs)
        if (ac != null && !ac.first.isImage) {
            val c = ac.first
            val idx = videoIds.indexOf(c.id)
            if (idx >= 0 && video.currentMediaItemIndex == idx) {
                if (video.playbackState == Player.STATE_BUFFERING) {
                    newPos = positionMs
                } else if (video.isPlaying) {
                    val vp = (video.currentPosition / c.speed).toLong() + ac.second
                    if (abs(vp - newPos) < 1000L) newPos = vp
                }
            }
        }

        positionMs = newPos.coerceIn(0L, total)
        if (positionMs >= total) {
            pause()
            return
        }
        syncAll(false)
    }

    private fun audioGain(a: AudioItem, t: Long): Float {
        var g = a.volume
        val local = t - a.startMs
        if (a.fadeInMs > 0L && local < a.fadeInMs) g *= local.coerceAtLeast(0L).toFloat() / a.fadeInMs
        val left = a.endMs - t
        if (a.fadeOutMs > 0L && left < a.fadeOutMs) g *= left.coerceAtLeast(0L).toFloat() / a.fadeOutMs
        return g.coerceIn(0f, 1f)
    }

    private fun syncAll(force: Boolean) {
        val t = positionMs
        val total = project.totalMs

        // الفيديو
        val ac = activeClip(t)
        if (ac != null && !ac.first.isImage) {
            val c = ac.first
            val idx = videoIds.indexOf(c.id)
            if (idx >= 0) {
                val desired = ((t - ac.second) * c.speed).toLong().coerceAtLeast(0L)
                if (force || video.currentMediaItemIndex != idx ||
                    abs(video.currentPosition - desired) > 400L
                ) {
                    video.seekTo(idx, desired)
                }
                if (video.playbackParameters.speed != c.speed) video.setPlaybackSpeed(c.speed)
                video.volume = if (c.muted) 0f else c.volume.coerceIn(0f, 1f)
                video.playWhenReady = playing
            }
        } else {
            video.playWhenReady = false
        }

        // الصوت
        for (a in project.audios) {
            val pl = audioPlayers[a.id] ?: continue
            if (t >= a.startMs && t < a.endMs && t < total) {
                val desired = t - a.startMs
                if (force || abs(pl.currentPosition - desired) > 350L) pl.seekTo(desired)
                pl.volume = audioGain(a, t)
                pl.playWhenReady = playing
            } else {
                pl.playWhenReady = false
                if (force) pl.seekTo(0L)
            }
        }
    }
}
